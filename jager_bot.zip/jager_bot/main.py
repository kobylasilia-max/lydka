# =====================================================================================
#  main.py — ТОЧКА ВХОДА JAGER CASINO BOT
# =====================================================================================
#
#  Структура проекта:
#    config.py            — все настройки (токен, ID админов, тайминги игр)
#    storage.py           — users.json, неблокирующее сохранение, профили
#    keyboards.py         — все клавиатуры
#    utils.py             — оформление, safe_edit, защита от двойного запуска, диагностика лагов
#    handlers/general.py  — /jager, Баланс, Топ, Дейли, Помощь, Перевести
#    handlers/admin.py    — русскоязычная админ-панель
#    handlers/roulette.py — рулетка
#    handlers/mines.py    — мины (3 уровня сложности)
#    handlers/upgrade.py  — апгрейд (кейс-баттл стиль)
#    handlers/shop.py     — магазин
#
#  УСТАНОВКА:  pip install aiogram==3.13.1
#  ЗАПУСК:     python main.py
#
# =====================================================================================

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramConflictError
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from handlers import all_routers
from storage import load_users, flush_users_now
from utils import TimingMiddleware, acquire_single_instance_lock, release_single_instance_lock
import runtime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("jager_bot")


async def main() -> None:
    # 1) Защита от случайного двойного запуска — самая частая причина хаотичных лагов.
    acquire_single_instance_lock()

    try:
        load_users()

        bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
        dp = Dispatcher(storage=MemoryStorage())

        me = await bot.get_me()
        runtime.BOT_USERNAME = me.username
        logger.info("Бот запущен как @%s", me.username)

        # 2) Диагностика: если обработка какого-то сообщения займёт больше
        #    config.SLOW_HANDLER_WARNING_SECONDS — в консоли появится явное предупреждение
        #    с указанием, что именно долго обрабатывалось.
        dp.update.outer_middleware(TimingMiddleware())

        for r in all_routers:
            dp.include_router(r)

        logger.info("Бот запускается...")
        await bot.delete_webhook(drop_pending_updates=True)

        try:
            await dp.start_polling(bot)
        except TelegramConflictError:
            logger.error(
                "❌ Telegram сообщил о КОНФЛИКТЕ getUpdates — где-то ещё запущена "
                "копия этого бота с тем же токеном (или бот работает через webhook). "
                "Остановите все остальные запущенные копии и перезапустите бота."
            )
        finally:
            await flush_users_now()
    finally:
        release_single_instance_lock()


if __name__ == "__main__":
    asyncio.run(main())
