# =====================================================================================
#  utils.py — ОБЩИЕ УТИЛИТЫ: ОФОРМЛЕНИЕ, БЕЗОПАСНОЕ РЕДАКТИРОВАНИЕ, ДИАГНОСТИКА ЛАГОВ
# =====================================================================================

import asyncio
import logging
import os
import sys
import time

from aiogram import Bot, BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter
from aiogram.types import InlineKeyboardMarkup, TelegramObject

from config import ADMIN_IDS, DIVIDER, LOCK_FILE, SLOW_HANDLER_WARNING_SECONDS

logger = logging.getLogger(__name__)


# =====================================================================================
#  ОФОРМЛЕНИЕ
# =====================================================================================

def header(title: str, emoji: str) -> str:
    """Единый заголовок для всех сообщений бота — меняется здесь, применяется сразу везде."""
    return f"『 {emoji} <b>{title.upper()}</b> 』\n{DIVIDER}\n\n"


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# =====================================================================================
#  БЕЗОПАСНОЕ РЕДАКТИРОВАНИЕ СООБЩЕНИЙ
# =====================================================================================

async def safe_edit(bot: Bot, chat_id: int, message_id: int, text: str, reply_markup: InlineKeyboardMarkup | None = None) -> None:
    """
    Обёртка над edit_message_text, устойчивая к типичным проблемам Telegram API:
      - TelegramRetryAfter (флуд-контроль) — ждём нужное время и повторяем один раз;
      - 'message is not modified' — молча игнорируем, это не ошибка;
      - прочие ошибки — логируем, но не роняем анимацию/игру.
    """
    try:
        await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=reply_markup)
    except TelegramRetryAfter as exc:
        logger.warning("Telegram попросил подождать %.1f сек (флуд-контроль)", exc.retry_after)
        await asyncio.sleep(exc.retry_after + 0.1)
        try:
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=reply_markup)
        except Exception as exc2:  # noqa: BLE001
            logger.debug("Повторное редактирование не удалось: %s", exc2)
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            logger.debug("Ошибка редактирования сообщения: %s", exc)
    except Exception as exc:  # noqa: BLE001
        logger.debug("Неожиданная ошибка при редактировании: %s", exc)


async def steady_countdown(bot: Bot, chat_id: int, message_id: int, total_seconds: int, text_builder,
                             poll_seconds: float = 0.15) -> None:
    """
    Обратный отсчёт без "зависаний" — финальная версия.

    История бага: сначала правки слались fire-and-forget (не дожидаясь ответа) —
    это позволяло накопиться очереди из наложившихся запросов, которая потом резко
    "прорывалась" разом. Затем попытались ждать каждую правку последовательно — но
    тогда ОДНА медленная правка (например, Telegram ответил RetryAfter) блокировала
    весь цикл опроса на всё это время, и таймер визуально "замирал".

    Правильное решение — третий вариант: опрашивающий цикл вообще НИКОГДА не ждёт
    сеть напрямую. Редактирование запускается как фоновая задача с ограничением
    "не более одной одновременно" — если предыдущая правка ещё не завершилась,
    цикл просто продолжает опрос дальше (не блокируясь), а как только слот
    освобождается — тут же берёт САМОЕ СВЕЖЕЕ значение, а не то, что скопилось.
    Это устраняет и очередь, и блокировку одновременно.
    """
    start = time.monotonic()
    last_shown: int | None = None
    pending: asyncio.Task | None = None

    while True:
        elapsed = time.monotonic() - start
        remaining = total_seconds - int(elapsed)
        if remaining <= 0:
            break

        slot_free = pending is None or pending.done()
        if remaining != last_shown and slot_free:
            pending = asyncio.create_task(safe_edit(bot, chat_id, message_id, text_builder(remaining)))
            last_shown = remaining

        await asyncio.sleep(poll_seconds)

    if pending is not None and not pending.done():
        try:
            await asyncio.wait_for(pending, timeout=2.0)
        except Exception:  # noqa: BLE001
            pass


# =====================================================================================
#  ЗАЩИТА ОТ ДВОЙНОГО ЗАПУСКА
# =====================================================================================
#
#  ОЧЕНЬ ЧАСТАЯ причина "то бот быстрый, то отвечает через 20 секунд" — это когда
#  случайно запущено ДВЕ копии бота одновременно (например, старый процесс не
#  закрылся после Ctrl+C или после падения консоли, а вы запустили ещё один).
#  Telegram в этом случае даёт обеим копиям конфликтующие ответы (ошибка
#  "Conflict: terminated by other getUpdates request"), обе копии уходят в retry
#  с задержками — и создаётся ощущение хаотичных лагов "то есть, то нет".
#
#  Ниже — простая защита: при старте бот создаёт файл-замок со своим PID.
#  Если файл уже существует и процесс с таким PID всё ещё жив — бот сразу
#  сообщает об этом и не запускается, вместо того чтобы тихо конфликтовать.
# =====================================================================================

def _pid_is_alive(pid: int) -> bool:
    if os.name == "nt":
        # На Windows нет os.kill(pid, 0), поэтому проверяем через tasklist.
        import subprocess
        try:
            output = subprocess.check_output(["tasklist", "/FI", f"PID eq {pid}"], text=True, stderr=subprocess.DEVNULL)
            return str(pid) in output
        except Exception:  # noqa: BLE001
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def acquire_single_instance_lock() -> None:
    """
    Проверяет, не запущена ли уже другая копия бота. Если да — выводит понятное
    сообщение и завершает процесс, вместо того чтобы обе копии молча конфликтовали.
    """
    if os.path.exists(LOCK_FILE):
        try:
            with open(LOCK_FILE, "r", encoding="utf-8") as f:
                old_pid = int(f.read().strip())
        except (ValueError, OSError):
            old_pid = None

        if old_pid is not None and _pid_is_alive(old_pid):
            print(
                "\n"
                "════════════════════════════════════════════════════════\n"
                f"  ⚠ Похоже, бот уже запущен в другом окне (PID {old_pid}).\n"
                "  Именно ОДНОВРЕМЕННЫЙ ЗАПУСК ДВУХ КОПИЙ БОТА — самая частая\n"
                "  причина хаотичных лагов (то быстро, то 15-20 секунд).\n\n"
                "  Закройте старое окно/процесс и запустите бота заново.\n"
                f"  Если вы уверены, что старой копии нет — удалите файл '{LOCK_FILE}'\n"
                "  и запустите бота ещё раз.\n"
                "════════════════════════════════════════════════════════\n"
            )
            sys.exit(1)

    with open(LOCK_FILE, "w", encoding="utf-8") as f:
        f.write(str(os.getpid()))


def release_single_instance_lock() -> None:
    try:
        if os.path.exists(LOCK_FILE):
            os.remove(LOCK_FILE)
    except OSError:
        pass


# =====================================================================================
#  ДИАГНОСТИКА ЛАГОВ: MIDDLEWARE, ЗАМЕРЯЮЩИЙ ВРЕМЯ ОБРАБОТКИ КАЖДОГО СООБЩЕНИЯ
# =====================================================================================

class TimingMiddleware(BaseMiddleware):
    """
    Оборачивает обработку КАЖДОГО апдейта (сообщения или нажатия кнопки) замером времени.
    Если обработка заняла дольше SLOW_HANDLER_WARNING_SECONDS — печатает предупреждение
    в консоль с указанием, что именно долго обрабатывалось. Это даёт точный ответ на
    вопрос "что именно тормозит", вместо гаданий.
    """

    async def __call__(self, handler, event: TelegramObject, data: dict):
        start = time.monotonic()
        try:
            return await handler(event, data)
        finally:
            elapsed = time.monotonic() - start
            if elapsed >= SLOW_HANDLER_WARNING_SECONDS:
                kind = type(event).__name__
                preview = ""
                text = getattr(event, "text", None) or getattr(getattr(event, "data", None), "__str__", lambda: "")()
                if isinstance(text, str):
                    preview = text[:40]
                logger.warning(
                    "⏱ МЕДЛЕННАЯ ОБРАБОТКА: %.1f сек | тип=%s | содержимое='%s'",
                    elapsed, kind, preview,
                )
