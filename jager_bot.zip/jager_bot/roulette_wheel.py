# =====================================================================================
#  roulette_wheel.py — GIF-КОЛЕСО ИГРЫ "ДЬЯВОЛ" (красное/чёрное)
# =====================================================================================
#
#  Рисует колесо через общий рендерер wheel_render.py (тень, глянец, объёмная втулка,
#  шлейф движения на скорости, искры и подсветка на остановке). Указатель наверху
#  фиксирован, вращается только само колесо. Формула поворота проверена: после
#  поворота на угол R сектор с центром theta_center оказывается ровно под указателем.
#
#  Итог ('red'/'black') уже определён нашим настоящим random() до отрисовки —
#  колесо только честно визуализирует его, не является источником случайности.
#
#  generate_wheel_gif() — CPU-задача, вызывать через asyncio.to_thread().
# =====================================================================================

import random

from wheel_render import render_spin_gif

SEGMENTS = 12
SEG_ANGLE = 360 / SEGMENTS
RED = (214, 40, 57)
BLACK = (20, 20, 24)

EXTRA_SPINS = 4


def generate_wheel_gif(result: str) -> bytes:
    matching = [i for i in range(SEGMENTS) if (i % 2 == 0) == (result == "red")]
    target_segment = random.choice(matching)
    theta_center = target_segment * SEG_ANGLE + SEG_ANGLE / 2
    base_rotation = (theta_center - 270) % 360

    direction = random.choice([1, -1])
    total_rotation = base_rotation + direction * EXTRA_SPINS * 360

    segments = [
        (i * SEG_ANGLE, (i + 1) * SEG_ANGLE, RED if i % 2 == 0 else BLACK)
        for i in range(SEGMENTS)
    ]
    return render_spin_gif(segments, total_rotation)
