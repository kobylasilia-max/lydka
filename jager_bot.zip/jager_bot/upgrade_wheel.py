# =====================================================================================
#  upgrade_wheel.py — GIF-КОЛЕСО ДЛЯ АПГРЕЙДА (зелёное/красное, пропорционально шансу)
# =====================================================================================
#
#  Рисует колесо через общий рендерер wheel_render.py. В отличие от игры "Дьявол"
#  (12 равных секторов), здесь всего два сектора — зелёный (победа) и красный
#  (проигрыш) — и их РАЗМЕР честно отражает реальный шанс победы для выбранного
#  множителя.
#
#  Итог (выиграл/проиграл) уже определён нашим настоящим random() до отрисовки —
#  колесо только честно визуализирует его, не является источником случайности.
# =====================================================================================

import random

from wheel_render import render_spin_gif

GREEN = (39, 174, 96)
RED = (192, 57, 43)

EXTRA_SPINS = 4
MIN_SEGMENT_DEGREES = 6  # визуальный минимум, чтобы тонкие шансы не пропадали совсем


def generate_upgrade_wheel_gif(win: bool, win_chance: float) -> bytes:
    green_angle = max(MIN_SEGMENT_DEGREES, min(360 - MIN_SEGMENT_DEGREES, win_chance * 360))

    if win:
        margin = green_angle * 0.15
        theta_target = random.uniform(margin, green_angle - margin) if green_angle > 2 * margin else green_angle / 2
    else:
        red_start = green_angle
        red_span = 360 - green_angle
        margin = red_span * 0.15
        theta_target = red_start + (
            random.uniform(margin, red_span - margin) if red_span > 2 * margin else red_span / 2
        )

    base_rotation = (theta_target - 270) % 360
    direction = random.choice([1, -1])
    total_rotation = base_rotation + direction * EXTRA_SPINS * 360

    segments = [(0, green_angle, GREEN), (green_angle, 360, RED)]
    return render_spin_gif(segments, total_rotation)
