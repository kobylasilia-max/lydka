# =====================================================================================
#  referrals.py — ДВУХУРОВНЕВАЯ РЕФЕРАЛЬНАЯ ПРОГРАММА
# =====================================================================================
#
#  Уровень 1 (прямой реферал): пригласили человека — как только он сыграет
#  REFERRAL_MIN_GAMES игр, вы получаете REFERRAL_REWARD_PREMIUM монет, если у него
#  Telegram Premium, иначе REFERRAL_REWARD_REGULAR.
#
#  Уровень 2 (цепочка): если ЭТОТ человек потом сам кого-то пригласит, и новый
#  человек тоже наберёт REFERRAL_MIN_GAMES игр — ВАМ (как "деду" в цепочке)
#  дополнительно капает REFERRAL_CHAIN_REWARD, независимо от Premium-статуса.
#
#  Оба начисления защищены условием "набрать N игр" — просто зарегистрировать
#  пустой аккаунт по ссылке ничего не даст.
# =====================================================================================

import logging

from aiogram import Bot

from config import REFERRAL_REWARD_REGULAR, REFERRAL_REWARD_PREMIUM, REFERRAL_CHAIN_REWARD, REFERRAL_MIN_GAMES
from storage import get_user, save_users, format_money

logger = logging.getLogger(__name__)


def _try_reward_referrer_sync(profile: dict) -> list[tuple[int, int]]:
    """
    Чистая логика без сети. Возвращает список (получатель, сумма) для уведомления —
    может быть один элемент (только прямой реферер) или два (реферер + "дед" в цепочке).
    """
    if not profile.get("referred_by"):
        return []
    if profile.get("referral_rewarded"):
        return []

    total_games = profile.get("wins", 0) + profile.get("losses", 0)
    if total_games < REFERRAL_MIN_GAMES:
        return []

    results: list[tuple[int, int]] = []

    # Уровень 1: прямой реферер.
    direct_id = profile["referred_by"]
    direct_amount = REFERRAL_REWARD_PREMIUM if profile.get("is_premium") else REFERRAL_REWARD_REGULAR
    direct_profile = get_user(direct_id)
    direct_profile["balance"] += direct_amount
    direct_profile["referral_earned"] = direct_profile.get("referral_earned", 0) + direct_amount
    results.append((direct_id, direct_amount))

    # Уровень 2: если у прямого реферера тоже есть свой реферер — цепочный бонус.
    chain_id = direct_profile.get("referred_by")
    if chain_id:
        chain_profile = get_user(chain_id)
        chain_profile["balance"] += REFERRAL_CHAIN_REWARD
        chain_profile["referral_earned"] = chain_profile.get("referral_earned", 0) + REFERRAL_CHAIN_REWARD
        results.append((chain_id, REFERRAL_CHAIN_REWARD))

    profile["referral_rewarded"] = True
    save_users()
    return results


async def check_and_notify_referral(bot: Bot, profile: dict) -> None:
    """Вызывать ПОСЛЕ каждого сыгранного раунда любой игры (когда wins/losses уже обновлены)."""
    rewards = _try_reward_referrer_sync(profile)
    for recipient_id, amount in rewards:
        try:
            await bot.send_message(
                recipient_id,
                "🎉 <b>Реферальная награда!</b>\n"
                f"Начислено <b>+{format_money(amount)}</b> монет.",
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Не удалось уведомить %s: %s", recipient_id, exc)
