# =====================================================================================
#  rocket_render.py — GIF ВЗРЫВА ДЛЯ ИГРЫ "РАКЕТА"
# =====================================================================================
#
#  Короткая яркая анимация взрыва (частицы разлетаются из центра с затуханием) —
#  показывается в момент краша раунда. Суперсэмплинг для чистых краёв, как и в
#  wheel_render.py.
# =====================================================================================

import io
import math
import random

from PIL import Image, ImageDraw, ImageFilter, ImageFont

SCALE = 2
SIZE = 360 * SCALE
OUT_SIZE = 360
CENTER = (SIZE // 2, SIZE // 2)

BACKGROUND = (10, 15, 26)
FLASH = (255, 250, 220)
PARTICLE_COLORS = [(255, 87, 34), (255, 152, 0), (255, 213, 79), (244, 67, 54), (255, 255, 255)]

FRAMES = 12
FRAME_MS = 70
N_PARTICLES = 30


def _load_label_font():
    """
    Крупный подписанный шрифт, если Pillow его поддерживает (load_default(size=...)
    появился в Pillow 10.1) — иначе тихо откатываемся на стандартный растровый шрифт.
    Никаких путей к файлам ОС — это ломалось бы на других системах (например, Windows).
    """
    try:
        return ImageFont.load_default(size=26)
    except TypeError:
        return ImageFont.load_default()


LABEL_FONT = _load_label_font()


def generate_explosion_gif(multiplier_text: str) -> bytes:
    rnd = random.Random()
    particles = []
    for _ in range(N_PARTICLES):
        angle = rnd.uniform(0, 2 * math.pi)
        speed = rnd.uniform(60, 170) * SCALE
        size = rnd.uniform(4, 11) * SCALE
        color = rnd.choice(PARTICLE_COLORS)
        particles.append((angle, speed, size, color))

    frames = []
    for f in range(FRAMES):
        t = f / (FRAMES - 1)
        img = Image.new("RGBA", (SIZE, SIZE), BACKGROUND + (255,))
        draw = ImageDraw.Draw(img)

        # Яркая вспышка в первые кадры, быстро гаснет.
        flash_alpha = max(0, int(220 * (1 - t * 3)))
        if flash_alpha > 0:
            flash_r = 40 * SCALE + t * 60 * SCALE
            fdraw_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
            fdraw = ImageDraw.Draw(fdraw_layer)
            fdraw.ellipse(
                [CENTER[0]-flash_r, CENTER[1]-flash_r, CENTER[0]+flash_r, CENTER[1]+flash_r],
                fill=FLASH + (flash_alpha,),
            )
            fdraw_layer = fdraw_layer.filter(ImageFilter.GaussianBlur(14 * SCALE))
            img.alpha_composite(fdraw_layer)

        ease_out = 1 - (1 - t) ** 2
        for angle, speed, size, color in particles:
            dist = speed * ease_out
            px = CENTER[0] + dist * math.cos(angle)
            py = CENTER[1] + dist * math.sin(angle)
            alpha = max(0, int(255 * (1 - t) ** 1.4))
            cur_size = size * (1 - t * 0.5)
            draw.ellipse([px-cur_size, py-cur_size, px+cur_size, py+cur_size], fill=color + (alpha,))

        frame = img.convert("RGB").resize((OUT_SIZE, OUT_SIZE), Image.LANCZOS)
        fdraw2 = ImageDraw.Draw(frame)
        if t > 0.35:
            text_alpha = min(255, int((t - 0.35) / 0.15 * 255))
            label = f"CRASH {multiplier_text}"
            bbox = fdraw2.textbbox((0, 0), label, font=LABEL_FONT)
            tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
            fdraw2.text(((OUT_SIZE-tw)//2, (OUT_SIZE-th)//2), label, fill=(255, 255, 255), font=LABEL_FONT)
        frames.append(frame)

    buf = io.BytesIO()
    frames[0].save(buf, format="GIF", save_all=True, append_images=frames[1:],
                    duration=FRAME_MS, loop=0, optimize=False, disposal=2)
    return buf.getvalue()
