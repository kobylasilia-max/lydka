# =====================================================================================
#  wheel_render.py — ОБЩИЙ ДВИЖОК ОТРИСОВКИ КОЛЁС (Дьявол + Апгрейд)
# =====================================================================================
#
#  ВАЖНО (история бага): более ранняя версия рисовала в 2x разрешении и добавляла
#  несколько "теневых" копий колеса на кадр (эффект шлейфа движения) — выглядело
#  красиво, но генерация одной гифки занимала 5-6+ секунд CPU-времени. На слабом
#  железе это ощутимо грузило процессор ЦЕЛИКОМ (Python — однопоточный по факту
#  выполнения байткода, GIL), и из-за этого "зависал" не только сам рендер, но и
#  event loop бота — отсюда синхронные жалобы на тормозящий таймер именно в моменты
#  игр с гифками. Здесь сознательно принесена в жертву часть красоты ради скорости:
#  без суперсэмплинга, без шлейфа, меньше кадров — но всё ещё с тенью, glow-кольцом
#  на победившем секторе и конфетти. Генерация укладывается в доли секунды.
# =====================================================================================

import io
import math
import random

from PIL import Image, ImageDraw, ImageFilter

SIZE = 280
CENTER = (SIZE // 2, SIZE // 2)
RADIUS = 120

OUT_SIZE = SIZE
CENTER_OUT = CENTER
RADIUS_OUT = RADIUS

GOLD = (222, 186, 90)
GOLD_LIGHT = (245, 220, 150)
GOLD_DARK = (140, 108, 30)
BACKGROUND = (10, 15, 26)
CONFETTI_COLORS = [(255, 215, 0), (255, 99, 132), (99, 200, 255), (140, 255, 150), (255, 255, 255)]

SPIN_FRAMES = 16
SPIN_FRAME_MS = 95
HOLD_FRAMES = 6
HOLD_FRAME_MS = 180
EXTRA_SPINS = 4


def _shadow_layer() -> Image.Image:
    shadow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(shadow)
    off = 8
    sbbox = [CENTER[0]-RADIUS-6+off, CENTER[1]-RADIUS-6+off, CENTER[0]+RADIUS+6+off, CENTER[1]+RADIUS+6+off]
    sdraw.ellipse(sbbox, fill=(0, 0, 0, 140))
    return shadow.filter(ImageFilter.GaussianBlur(6))


def _gloss_layer() -> Image.Image:
    gloss = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(gloss)
    gx, gy = CENTER[0] - RADIUS * 0.35, CENTER[1] - RADIUS * 0.45
    gr = RADIUS * 0.75
    gdraw.ellipse([gx-gr, gy-gr*0.6, gx+gr, gy+gr*0.6], fill=(255, 255, 255, 35))
    return gloss.filter(ImageFilter.GaussianBlur(10))


# Статичные слои — считаются ОДИН РАЗ при импорте модуля, а не на каждый кадр.
SHADOW = _shadow_layer()
GLOSS = _gloss_layer()


def _draw_segments(segments, rotation_deg) -> Image.Image:
    wheel = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    wdraw = ImageDraw.Draw(wheel)
    bbox = [CENTER[0] - RADIUS, CENTER[1] - RADIUS, CENTER[0] + RADIUS, CENTER[1] + RADIUS]
    for start, end, color in segments:
        wdraw.pieslice(bbox, start, end, fill=color, outline=GOLD, width=2)
    return wheel.rotate(rotation_deg, resample=Image.BILINEAR, center=CENTER)


def render_frame(segments, rotation_deg: float, highlight_alpha: int = 0,
                  sparkle_seed: int | None = None) -> Image.Image:
    img = Image.new("RGBA", (SIZE, SIZE), BACKGROUND + (255,))
    img.alpha_composite(SHADOW)

    draw = ImageDraw.Draw(img)
    outer_bbox = [CENTER[0]-RADIUS-8, CENTER[1]-RADIUS-8, CENTER[0]+RADIUS+8, CENTER[1]+RADIUS+8]
    draw.ellipse(outer_bbox, fill=GOLD_DARK)

    img.alpha_composite(_draw_segments(segments, rotation_deg))

    bbox = [CENTER[0]-RADIUS, CENTER[1]-RADIUS, CENTER[0]+RADIUS, CENTER[1]+RADIUS]
    draw.ellipse(bbox, outline=GOLD, width=3)

    img.alpha_composite(GLOSS)

    if highlight_alpha > 0:
        ring_bbox = [CENTER[0]-RADIUS-5, CENTER[1]-RADIUS-5, CENTER[0]+RADIUS+5, CENTER[1]+RADIUS+5]
        draw.arc(ring_bbox, 250, 290, fill=(255, 255, 255, highlight_alpha), width=12)

        if sparkle_seed is not None:
            rnd = random.Random(sparkle_seed)
            for _ in range(6):
                ang = math.radians(rnd.uniform(0, 360))
                dist = rnd.uniform(RADIUS * 0.3, RADIUS + 30)
                sx = CENTER[0] + dist * math.cos(ang)
                sy = CENTER[1] - dist * 0.9
                size = rnd.uniform(2, 5)
                color = rnd.choice(CONFETTI_COLORS)
                a = int(highlight_alpha * rnd.uniform(0.5, 1.0))
                draw.ellipse([sx-size, sy-size, sx+size, sy+size], fill=color + (a,))

    hub_r = 17
    draw.ellipse([CENTER[0]-hub_r, CENTER[1]-hub_r, CENTER[0]+hub_r, CENTER[1]+hub_r],
                 fill=GOLD_LIGHT, outline=GOLD_DARK, width=2)

    pointer_scale = 1.0 + (highlight_alpha / 255) * 0.25
    pw, ph = int(22*pointer_scale), int(30*pointer_scale)
    px, py = CENTER[0], CENTER[1] - RADIUS - 4
    pointer_color = GOLD_LIGHT if highlight_alpha == 0 else (255, 240, 190)
    draw.polygon([(px-pw//2, py-ph), (px+pw//2, py-ph), (px, py)], fill=pointer_color, outline=GOLD_DARK)

    return img.convert("RGB")


def render_spin_gif(segments, target_rotation: float) -> bytes:
    frames, durations = [], []

    for f in range(SPIN_FRAMES):
        t = f / (SPIN_FRAMES - 1)
        eased = 1 - (1 - t) ** 3
        frames.append(render_frame(segments, target_rotation * eased))
        durations.append(SPIN_FRAME_MS)

    for h in range(HOLD_FRAMES):
        pulse = 140 + int(100 * abs((h % 4) - 2) / 2)
        frames.append(render_frame(segments, target_rotation, highlight_alpha=pulse, sparkle_seed=h))
        durations.append(HOLD_FRAME_MS)

    buf = io.BytesIO()
    frames[0].save(buf, format="GIF", save_all=True, append_images=frames[1:],
                    duration=durations, loop=0, optimize=False, disposal=2)
    return buf.getvalue()
