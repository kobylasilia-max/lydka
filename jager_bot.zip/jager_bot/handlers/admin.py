# =====================================================================================
#  handlers/admin.py — АДМИН-ПАНЕЛЬ (на русском, естественными фразами)
# =====================================================================================

import re

from aiogram import Router, F
from aiogram.types import Message

from storage import resolve_target, format_money, display_name, save_users
from utils import header, is_admin

router = Router(name="admin")

ADMIN_GIVE_PATTERN = re.compile(r"^\s*выдать(?:\s+баланс)?\s+(\S+)\s+(\d+)\s*$", re.IGNORECASE)
ADMIN_REMOVE_PATTERN = re.compile(r"^\s*снять(?:\s+баланс)?\s+(\S+)\s+(\d+)\s*$", re.IGNORECASE)
ADMIN_SET_PATTERN = re.compile(r"^\s*установить(?:\s+баланс)?\s+(\S+)\s+(\d+)\s*$", re.IGNORECASE)
ADMIN_BAN_PATTERN = re.compile(r"^\s*забанить\s+(\S+)\s*$", re.IGNORECASE)
ADMIN_UNBAN_PATTERN = re.compile(r"^\s*разбанить\s+(\S+)\s*$", re.IGNORECASE)


@router.message(F.text.regexp(ADMIN_GIVE_PATTERN))
async def admin_give(message: Message) -> None:
    """выдать @username 1000 / выдать себе 1000 / выдать 123456789 1000"""
    if not is_admin(message.from_user.id):
        return

    match = ADMIN_GIVE_PATTERN.match(message.text.strip())
    target_raw, amount_str = match.group(1), match.group(2)
    amount = int(amount_str)
    if amount <= 0:
        await message.reply("Сумма должна быть больше нуля.")
        return

    profile = resolve_target(target_raw, message.from_user.id, message.from_user.username, message.from_user.full_name)
    if profile is None:
        await message.reply("Пользователь не найден — возможно, он ещё не запускал бота.")
        return

    profile["balance"] += amount
    save_users()
    text = (
        header("Выдача монет", "✅")
        + f"Получатель: {display_name(profile)}\n"
        + f"Начислено: +{format_money(amount)}\n"
        + f"Новый баланс: {format_money(profile['balance'])}"
    )
    await message.reply(text)


@router.message(F.text.regexp(ADMIN_REMOVE_PATTERN))
async def admin_remove(message: Message) -> None:
    """снять @username 1000 / снять баланс @username 1000"""
    if not is_admin(message.from_user.id):
        return

    match = ADMIN_REMOVE_PATTERN.match(message.text.strip())
    target_raw, amount_str = match.group(1), match.group(2)
    amount = int(amount_str)
    if amount <= 0:
        await message.reply("Сумма должна быть больше нуля.")
        return

    profile = resolve_target(target_raw, message.from_user.id, message.from_user.username, message.from_user.full_name)
    if profile is None:
        await message.reply("Пользователь не найден — возможно, он ещё не запускал бота.")
        return

    profile["balance"] = max(0, profile["balance"] - amount)
    save_users()
    text = (
        header("Списание монет", "✅")
        + f"У кого: {display_name(profile)}\n"
        + f"Списано: -{format_money(amount)}\n"
        + f"Новый баланс: {format_money(profile['balance'])}"
    )
    await message.reply(text)


@router.message(F.text.regexp(ADMIN_SET_PATTERN))
async def admin_set(message: Message) -> None:
    """установить @username 1000 — задать точный баланс"""
    if not is_admin(message.from_user.id):
        return

    match = ADMIN_SET_PATTERN.match(message.text.strip())
    target_raw, amount_str = match.group(1), match.group(2)
    amount = int(amount_str)

    profile = resolve_target(target_raw, message.from_user.id, message.from_user.username, message.from_user.full_name)
    if profile is None:
        await message.reply("Пользователь не найден — возможно, он ещё не запускал бота.")
        return

    profile["balance"] = amount
    save_users()
    text = (
        header("Баланс изменён", "✅")
        + f"Пользователь: {display_name(profile)}\n"
        + f"Новый баланс: {format_money(profile['balance'])}"
    )
    await message.reply(text)


@router.message(F.text.regexp(ADMIN_BAN_PATTERN))
async def admin_ban(message: Message) -> None:
    """забанить @username"""
    if not is_admin(message.from_user.id):
        return

    match = ADMIN_BAN_PATTERN.match(message.text.strip())
    target_raw = match.group(1)

    profile = resolve_target(target_raw, message.from_user.id, message.from_user.username, message.from_user.full_name)
    if profile is None:
        await message.reply("Пользователь не найден.")
        return

    profile["banned"] = True
    save_users()
    await message.reply(f"🚫 {display_name(profile)} заблокирован.")


@router.message(F.text.regexp(ADMIN_UNBAN_PATTERN))
async def admin_unban(message: Message) -> None:
    """разбанить @username"""
    if not is_admin(message.from_user.id):
        return

    match = ADMIN_UNBAN_PATTERN.match(message.text.strip())
    target_raw = match.group(1)

    profile = resolve_target(target_raw, message.from_user.id, message.from_user.username, message.from_user.full_name)
    if profile is None:
        await message.reply("Пользователь не найден.")
        return

    profile["banned"] = False
    save_users()
    await message.reply(f"✅ {display_name(profile)} разблокирован.")
