# =====================================================================================
#  handlers/mines.py — МИНЫ: "мины 500" -> выбор сложности -> игра
# =====================================================================================
#
#  Ключевой момент этого модуля — mines_locks. Без персональной блокировки на игру
#  два быстрых клика подряд обрабатывались бы параллельно и могли перезаписать
#  состояние друг друга (отсюда клетки, ошибочно показывающие "игра завершена").
#  Теперь все действия одной игры строго ставятся в очередь.
#
#  Количество мин теперь выбирается игроком (лёгкий/средний/сложный), а не задано
#  константой — поэтому оно хранится в самой игре (game["mines_count"]), а не берётся
#  из config напрямую.
# =====================================================================================

import asyncio
import random
import re

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from config import MINES_GRID_SIZE, MINES_TIERS, DIVIDER
from storage import get_user, format_money, save_users, add_wagered
from utils import header, safe_edit
from keyboards import mines_keyboard, mines_tier_keyboard
from gamemath import mines_multiplier
from referrals import check_and_notify_referral

router = Router(name="mines")

mines_games: dict[str, dict] = {}          # str(user_id) -> состояние игры
mines_locks: dict[str, asyncio.Lock] = {}  # str(user_id) -> персональная блокировка

MINES_TEXT_PATTERN = re.compile(r"^\s*мины\s+(\d+)\s*$", re.IGNORECASE)
MINES_CANCEL_WORDS = {"отмена мины", "отменить мины", "убрать мины", "сбросить мины"}
TIER_LABELS = {count: label for _key, count, label in MINES_TIERS}


def get_mines_lock(uid: str) -> asyncio.Lock:
    if uid not in mines_locks:
        mines_locks[uid] = asyncio.Lock()
    return mines_locks[uid]


def mines_status_text(game: dict, finished: bool = False, result_line: str | None = None) -> str:
    safe_opened = len(game["revealed"])
    total_cells = MINES_GRID_SIZE * MINES_GRID_SIZE
    mines_count = game["mines_count"]
    multiplier = mines_multiplier(safe_opened, mines_count, total_cells)
    potential = int(game["bet"] * multiplier)
    tier_label = TIER_LABELS.get(mines_count, f"{mines_count} мин")

    text = (
        header("Мины", "💣")
        + f"Сложность: {tier_label}\n"
        + f"Ставка: <b>{format_money(game['bet'])}</b>\n"
        + f"Открыто безопасных: {safe_opened}\n"
        + f"Множитель: <b>x{multiplier:.2f}</b>\n"
        + f"Текущий выигрыш: <b>{format_money(potential)}</b>\n"
        + f"{DIVIDER}\n"
    )
    if finished:
        text += result_line or ""
    else:
        text += "Открывайте клетки 💎 или нажмите «Забрать выигрыш»"
    return text


# =====================================================================================
#  ШАГ 1: "мины 500" — проверяем ставку и показываем выбор сложности
# =====================================================================================

@router.message(F.text.regexp(MINES_TEXT_PATTERN))
async def mines_text_trigger(message: Message) -> None:
    match = MINES_TEXT_PATTERN.match(message.text.strip())
    bet = int(match.group(1))

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        await message.answer("🚫 Вы заблокированы и не можете играть.")
        return

    uid = str(message.from_user.id)
    if uid in mines_games:
        await message.answer(
            "⛔ У вас уже есть активная игра Мины. Завершите её, прежде чем начать новую.\n"
            "Если это ошибка (игра зависла) — напишите «отмена мины», ставка вернётся."
        )
        return
    if bet <= 0:
        await message.answer("Сумма ставки должна быть больше нуля.")
        return
    if user["balance"] < bet:
        await message.answer("Недостаточно средств на балансе.")
        return

    text = (
        header("Мины", "💣")
        + f"Ставка: <b>{format_money(bet)}</b>\n"
        + f"{DIVIDER}\n"
        + "Выберите сложность — чем больше мин, тем быстрее растёт множитель:"
    )
    await message.answer(text, reply_markup=mines_tier_keyboard(message.from_user.id, bet))


@router.message(F.text.func(lambda t: t.strip().lower() in MINES_CANCEL_WORDS))
async def mines_cancel(message: Message) -> None:
    """
    Аварийный выход. Если бот считает, что у игрока есть активная игра, хотя по
    факту она уже завершена (редкий сбой синхронизации) — эта команда снимает
    состояние вручную и возвращает ставку, чтобы человек не застревал навсегда.
    """
    uid = str(message.from_user.id)
    lock = get_mines_lock(uid)
    async with lock:
        game = mines_games.get(uid)
        if game is None:
            await message.answer("У вас нет активной игры Мины — отменять нечего.")
            return

        user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
        user["balance"] += game["bet"]
        save_users()

        try:
            await safe_edit(
                message.bot, game["chat_id"], game["message_id"],
                mines_status_text(game, finished=True, result_line="🚫 <b>Игра отменена, ставка возвращена.</b>"),
                reply_markup=mines_keyboard(game, message.from_user.id, reveal_all=True),
            )
        except Exception:  # noqa: BLE001
            pass  # старое сообщение могло быть удалено — не критично

        mines_games.pop(uid, None)
        await message.answer(f"✅ Игра отменена. Возвращено {format_money(game['bet'])}.")


# =====================================================================================
#  ШАГ 2: выбор сложности — списываем ставку и запускаем реальную игру
# =====================================================================================

@router.callback_query(F.data.startswith("mines_tier:"))
async def cb_mines_tier(callback: CallbackQuery) -> None:
    try:
        _, owner_id_str, mines_count_str, bet_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        mines_count = int(mines_count_str)
        bet = int(bet_str)
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_mines_lock(uid)
    async with lock:
        if uid in mines_games:
            await callback.answer("У вас уже есть активная игра Мины.", show_alert=True)
            return

        user = get_user(owner_id)
        if user.get("banned"):
            await callback.answer("Вы заблокированы.", show_alert=True)
            return
        if user["balance"] < bet:
            await callback.answer("Недостаточно средств на балансе.", show_alert=True)
            return

        user["balance"] -= bet
        add_wagered(user, bet)
        save_users()

        total_cells = MINES_GRID_SIZE * MINES_GRID_SIZE
        mines = set(random.sample(range(total_cells), mines_count))

        game = {
            "bet": bet,
            "mines": mines,
            "mines_count": mines_count,
            "revealed": set(),
            "chat_id": callback.message.chat.id,
            "message_id": callback.message.message_id,
            "owner_id": owner_id,
        }
        mines_games[uid] = game

        await callback.answer(f"Сложность: {TIER_LABELS.get(mines_count, mines_count)}")
        await callback.message.edit_text(
            mines_status_text(game),
            reply_markup=mines_keyboard(game, owner_id),
        )


# =====================================================================================
#  ИГРОВОЙ ПРОЦЕСС
# =====================================================================================

@router.callback_query(F.data == "mines_noop")
async def cb_mines_noop(callback: CallbackQuery) -> None:
    await callback.answer("Эта клетка уже открыта.")


@router.callback_query(F.data.startswith("mines_cell:"))
async def cb_mines_cell(callback: CallbackQuery) -> None:
    try:
        _, owner_id_str, idx_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        idx = int(idx_str)
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_mines_lock(uid)

    async with lock:
        game = mines_games.get(uid)
        if game is None or game["message_id"] != callback.message.message_id:
            await callback.answer("Эта игра уже завершена.", show_alert=True)
            return

        if idx in game["revealed"]:
            await callback.answer("Эта клетка уже открыта.")
            return

        if idx in game["mines"]:
            # Сначала МГНОВЕННО отвечаем на нажатие (снимает "крутилку" с кнопки в Telegram),
            # и только потом делаем более медленный сетевой запрос на редактирование сообщения.
            await callback.answer("💥 Мина! Игра окончена.")

            profile = get_user(owner_id)
            profile["losses"] += 1
            save_users()
            await check_and_notify_referral(callback.bot, profile)

            text = mines_status_text(game, finished=True, result_line="💥 <b>Взрыв! Вы потеряли ставку.</b>")
            await safe_edit(
                callback.bot, game["chat_id"], game["message_id"], text,
                reply_markup=mines_keyboard(game, owner_id, reveal_all=True),
            )
            mines_games.pop(uid, None)
            return

        game["revealed"].add(idx)
        total_cells = MINES_GRID_SIZE * MINES_GRID_SIZE
        safe_cells_total = total_cells - game["mines_count"]

        if len(game["revealed"]) >= safe_cells_total:
            await _cash_out_mines_locked(callback, game, owner_id, auto=True)
            return

        # Тот же принцип: мгновенный ответ до редактирования сообщения.
        await callback.answer("💎 Безопасно!")
        await safe_edit(
            callback.bot, game["chat_id"], game["message_id"],
            mines_status_text(game),
            reply_markup=mines_keyboard(game, owner_id),
        )


@router.callback_query(F.data.startswith("mines_cashout:"))
async def cb_mines_cashout(callback: CallbackQuery) -> None:
    try:
        owner_id = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_mines_lock(uid)
    async with lock:
        game = mines_games.get(uid)
        if game is None or game["message_id"] != callback.message.message_id:
            await callback.answer("Эта игра уже завершена.", show_alert=True)
            return
        await _cash_out_mines_locked(callback, game, owner_id, auto=False)


async def _cash_out_mines_locked(callback: CallbackQuery, game: dict, owner_id: int, auto: bool) -> None:
    """Вызывается только изнутри 'async with lock' — повторно блокировку не берёт."""
    uid = str(owner_id)
    safe_opened = len(game["revealed"])
    total_cells = MINES_GRID_SIZE * MINES_GRID_SIZE
    multiplier = mines_multiplier(safe_opened, game["mines_count"], total_cells)
    payout = int(game["bet"] * multiplier)

    # Мгновенный ответ на нажатие — до сетевого запроса редактирования сообщения.
    await callback.answer(f"Выигрыш {format_money(payout)} зачислен!")

    profile = get_user(owner_id)
    profile["balance"] += payout
    profile["wins"] += 1
    save_users()
    await check_and_notify_referral(callback.bot, profile)

    result_line = f"✅ <b>Выигрыш выведен: {format_money(payout)}</b>"
    if auto:
        result_line = "🎉 <b>Все клетки открыты!</b>\n" + result_line

    text = mines_status_text(game, finished=True, result_line=result_line)
    await safe_edit(
        callback.bot, game["chat_id"], game["message_id"], text,
        reply_markup=mines_keyboard(game, owner_id, reveal_all=True),
    )

    mines_games.pop(uid, None)
