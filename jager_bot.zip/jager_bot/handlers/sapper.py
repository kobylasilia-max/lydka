# =====================================================================================
#  handlers/sapper.py — САПЁР: "сапер 500" (классические числа-подсказки)
# =====================================================================================
#
#  Отличие от "Мин": на открытой безопасной клетке видно ЧИСЛО — сколько мин среди
#  8 соседних клеток (настоящая механика минного поля, как в классическом сапёре),
#  а не просто "открыто/не открыто". Это даёт немного больше информации думающему
#  игроку. Поле больше (6x6), мин тоже больше — честный множитель считается той же
#  формулой gamemath.mines_multiplier, что и в "Минах".
#
#  Технически устроен так же, как handlers/mines.py: персональная блокировка на
#  игру (защита от гонок при быстрых кликах), мгновенный ответ на нажатие ДО
#  редактирования сообщения (не "виснет" кнопка), команда аварийной отмены.
# =====================================================================================

import asyncio
import random
import re

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from config import SAPPER_GRID_SIZE, SAPPER_MINES_COUNT, DIVIDER
from storage import get_user, format_money, save_users, add_wagered
from utils import header, safe_edit
from keyboards import sapper_keyboard
from gamemath import mines_multiplier
from referrals import check_and_notify_referral

router = Router(name="sapper")

sapper_games: dict[str, dict] = {}
sapper_locks: dict[str, asyncio.Lock] = {}

SAPPER_TEXT_PATTERN = re.compile(r"^\s*сап[её]р\s+(\d+)\s*$", re.IGNORECASE)
SAPPER_CANCEL_WORDS = {"отмена сапер", "отмена сапёр", "отменить сапер", "отменить сапёр"}


def get_sapper_lock(uid: str) -> asyncio.Lock:
    if uid not in sapper_locks:
        sapper_locks[uid] = asyncio.Lock()
    return sapper_locks[uid]


def _count_adjacent_mines(idx: int, mines: set[int], grid_size: int) -> int:
    r, c = divmod(idx, grid_size)
    count = 0
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if dr == 0 and dc == 0:
                continue
            nr, nc = r + dr, c + dc
            if 0 <= nr < grid_size and 0 <= nc < grid_size:
                if nr * grid_size + nc in mines:
                    count += 1
    return count


def _flood_reveal(start_idx: int, mines: set[int], hints: dict[int, int], grid_size: int,
                   already_revealed: set[int]) -> list[int]:
    """
    Каскадное открытие — КАК В ОРИГИНАЛЬНОМ САПЁРЕ: если у открытой клетки 0 мин
    среди соседей, автоматически открываются все её соседи, и так далее по цепочке
    (BFS), пока цепочка не упрётся в клетки с ненулевой подсказкой. Одним кликом
    по "пустой" области может открыться сразу много клеток — это и есть тот самый
    оригинальный эффект, ради которого вообще нужны числа-подсказки.
    """
    from collections import deque

    visited = set(already_revealed)
    queue = deque([start_idx])
    newly_revealed: list[int] = []

    while queue:
        idx = queue.popleft()
        if idx in visited or idx in mines:
            continue
        visited.add(idx)
        newly_revealed.append(idx)

        if hints.get(idx, 0) == 0:
            r, c = divmod(idx, grid_size)
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < grid_size and 0 <= nc < grid_size:
                        nidx = nr * grid_size + nc
                        if nidx not in visited and nidx not in mines:
                            queue.append(nidx)

    return newly_revealed


def sapper_status_text(game: dict, finished: bool = False, result_line: str | None = None) -> str:
    safe_opened = len(game["revealed"])
    total_cells = SAPPER_GRID_SIZE * SAPPER_GRID_SIZE
    multiplier = mines_multiplier(safe_opened, SAPPER_MINES_COUNT, total_cells)
    potential = int(game["bet"] * multiplier)

    text = (
        header("Сапёр", "🧨")
        + f"Ставка: <b>{format_money(game['bet'])}</b>\n"
        + f"Мин на поле: {SAPPER_MINES_COUNT} из {total_cells}\n"
        + f"Открыто безопасных: {safe_opened}\n"
        + f"Множитель: <b>x{multiplier:.2f}</b>\n"
        + f"Текущий выигрыш: <b>{format_money(potential)}</b>\n"
        + f"{DIVIDER}\n"
    )
    if finished:
        text += result_line or ""
    else:
        text += "Числа показывают, сколько мин среди соседних клеток."
    return text


@router.message(F.text.regexp(SAPPER_TEXT_PATTERN))
async def sapper_text_trigger(message: Message) -> None:
    match = SAPPER_TEXT_PATTERN.match(message.text.strip())
    bet = int(match.group(1))

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        await message.answer("🚫 Вы заблокированы и не можете играть.")
        return

    uid = str(message.from_user.id)
    lock = get_sapper_lock(uid)
    async with lock:
        if uid in sapper_games:
            await message.answer(
                "⛔ У вас уже есть активная игра Сапёр.\n"
                "Если это ошибка (игра зависла) — напишите «отмена сапёр»."
            )
            return
        if bet <= 0:
            await message.answer("Сумма ставки должна быть больше нуля.")
            return
        if user["balance"] < bet:
            await message.answer("Недостаточно средств на балансе.")
            return

        user["balance"] -= bet
        add_wagered(user, bet)
        save_users()

        total_cells = SAPPER_GRID_SIZE * SAPPER_GRID_SIZE
        mines = set(random.sample(range(total_cells), SAPPER_MINES_COUNT))
        hints = {i: _count_adjacent_mines(i, mines, SAPPER_GRID_SIZE) for i in range(total_cells) if i not in mines}

        game = {
            "bet": bet,
            "mines": mines,
            "hints": hints,
            "revealed": set(),
            "chat_id": message.chat.id,
            "message_id": None,
            "owner_id": message.from_user.id,
        }
        sapper_games[uid] = game

        sent = await message.answer(sapper_status_text(game), reply_markup=sapper_keyboard(game, message.from_user.id))
        game["message_id"] = sent.message_id


@router.message(F.text.func(lambda t: t.strip().lower() in SAPPER_CANCEL_WORDS))
async def sapper_cancel(message: Message) -> None:
    uid = str(message.from_user.id)
    lock = get_sapper_lock(uid)
    async with lock:
        game = sapper_games.get(uid)
        if game is None:
            await message.answer("У вас нет активной игры Сапёр — отменять нечего.")
            return

        user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
        user["balance"] += game["bet"]
        save_users()

        try:
            await safe_edit(
                message.bot, game["chat_id"], game["message_id"],
                sapper_status_text(game, finished=True, result_line="🚫 <b>Игра отменена, ставка возвращена.</b>"),
                reply_markup=sapper_keyboard(game, message.from_user.id, reveal_all=True),
            )
        except Exception:  # noqa: BLE001
            pass

        sapper_games.pop(uid, None)
        await message.answer(f"✅ Игра отменена. Возвращено {format_money(game['bet'])}.")


@router.callback_query(F.data == "sapper_noop")
async def cb_sapper_noop(callback: CallbackQuery) -> None:
    await callback.answer("Эта клетка уже открыта.")


@router.callback_query(F.data.startswith("sapper_cell:"))
async def cb_sapper_cell(callback: CallbackQuery) -> None:
    try:
        _, owner_id_str, idx_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        idx = int(idx_str)
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_sapper_lock(uid)

    async with lock:
        game = sapper_games.get(uid)
        if game is None or game["message_id"] != callback.message.message_id:
            await callback.answer("Эта игра уже завершена.", show_alert=True)
            return

        if idx in game["revealed"]:
            await callback.answer("Эта клетка уже открыта.")
            return

        if idx in game["mines"]:
            await callback.answer("💥 Мина! Игра окончена.")

            profile = get_user(owner_id)
            profile["losses"] += 1
            save_users()
            await check_and_notify_referral(callback.bot, profile)

            text = sapper_status_text(game, finished=True, result_line="💥 <b>Взрыв! Вы потеряли ставку.</b>")
            await safe_edit(
                callback.bot, game["chat_id"], game["message_id"], text,
                reply_markup=sapper_keyboard(game, owner_id, reveal_all=True),
            )
            sapper_games.pop(uid, None)
            return

        newly_revealed = _flood_reveal(idx, game["mines"], game["hints"], SAPPER_GRID_SIZE, game["revealed"])
        game["revealed"].update(newly_revealed)
        total_cells = SAPPER_GRID_SIZE * SAPPER_GRID_SIZE
        safe_cells_total = total_cells - SAPPER_MINES_COUNT

        if len(game["revealed"]) >= safe_cells_total:
            await _cash_out_sapper_locked(callback, game, owner_id, auto=True)
            return

        if len(newly_revealed) > 1:
            await callback.answer(f"💥 Пустая область — открыто клеток: {len(newly_revealed)}!")
        else:
            await callback.answer(f"Соседних мин: {game['hints'][idx]}")
        await safe_edit(
            callback.bot, game["chat_id"], game["message_id"],
            sapper_status_text(game),
            reply_markup=sapper_keyboard(game, owner_id),
        )


@router.callback_query(F.data.startswith("sapper_cashout:"))
async def cb_sapper_cashout(callback: CallbackQuery) -> None:
    try:
        owner_id = int(callback.data.split(":")[1])
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_sapper_lock(uid)
    async with lock:
        game = sapper_games.get(uid)
        if game is None or game["message_id"] != callback.message.message_id:
            await callback.answer("Эта игра уже завершена.", show_alert=True)
            return
        await _cash_out_sapper_locked(callback, game, owner_id, auto=False)


async def _cash_out_sapper_locked(callback: CallbackQuery, game: dict, owner_id: int, auto: bool) -> None:
    uid = str(owner_id)
    safe_opened = len(game["revealed"])
    total_cells = SAPPER_GRID_SIZE * SAPPER_GRID_SIZE
    multiplier = mines_multiplier(safe_opened, SAPPER_MINES_COUNT, total_cells)
    payout = int(game["bet"] * multiplier)

    await callback.answer(f"Выигрыш {format_money(payout)} зачислен!")

    profile = get_user(owner_id)
    profile["balance"] += payout
    profile["wins"] += 1
    save_users()
    await check_and_notify_referral(callback.bot, profile)

    result_line = f"✅ <b>Выигрыш выведен: {format_money(payout)}</b>"
    if auto:
        result_line = "🎉 <b>Все клетки открыты!</b>\n" + result_line

    text = sapper_status_text(game, finished=True, result_line=result_line)
    await safe_edit(
        callback.bot, game["chat_id"], game["message_id"], text,
        reply_markup=sapper_keyboard(game, owner_id, reveal_all=True),
    )

    sapper_games.pop(uid, None)
