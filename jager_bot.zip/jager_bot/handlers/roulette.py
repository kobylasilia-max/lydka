# =====================================================================================
#  handlers/roulette.py — ДЬЯВОЛ (только в группах): "1000 к" / "1000 ч"
# =====================================================================================

import asyncio
import random
import re

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.types import Message, BufferedInputFile

from config import BET_TIME_SECONDS, DIVIDER
from storage import get_user, format_money, save_users, add_wagered
from utils import header, safe_edit, steady_countdown
from roulette_wheel import generate_wheel_gif
from referrals import check_and_notify_referral

router = Router(name="roulette")

# chat_id -> состояние текущего раунда
roulette_rounds: dict[int, dict] = {}

ROULETTE_BET_PATTERN = re.compile(r"^\s*(\d+)\s*([кч])\s*$", re.IGNORECASE)


def build_betting_text(round_data: dict, remaining: int) -> str:
    bets = round_data["bets"]
    red_total = sum(b["amount"] for b in bets.values() if b["color"] == "red")
    black_total = sum(b["amount"] for b in bets.values() if b["color"] == "black")
    players = len(bets)

    return (
        header("Дьявол", "😈")
        + f"⏱ До конца ставок: <b>{remaining}</b> сек.\n\n"
        + f"🔴 Красное — {format_money(red_total)}\n"
        + f"⚫ Чёрное — {format_money(black_total)}\n\n"
        + f"👥 Игроков: {players}\n"
        + f"{DIVIDER}\n"
        + "Ставка сообщением: <code>1000 к</code> или <code>1000 ч</code>"
    )


async def finish_roulette_round(bot: Bot, chat_id: int, result: str) -> None:
    round_data = roulette_rounds[chat_id]
    bets = round_data["bets"]
    result_label = "🔴 Красное" if result == "red" else "⚫ Чёрное"

    winners_lines = []
    for uid, bet in bets.items():
        profile = get_user(int(uid))
        if bet["color"] == result:
            win_amount = bet["amount"] * 2
            profile["balance"] += win_amount
            profile["wins"] += 1
            uname = bet["username"]
            name_display = f"@{uname}" if uname else f"id{uid}"
            winners_lines.append(f"✅ {name_display} +{format_money(win_amount)}")
        else:
            profile["losses"] += 1
        await check_and_notify_referral(bot, profile)
    save_users()

    text = header("Дьявол", "😈") + f"Результат: <b>{result_label}</b>\n\n"
    if winners_lines:
        text += "🏆 <b>Победители:</b>\n" + "\n".join(winners_lines)
    else:
        text += "В этом раунде победителей нет."

    # ВАЖНО: результат отправляем НОВЫМ сообщением, а не правкой старого — так он
    # появляется сразу ПОД анимацией колеса, а не выше неё в истории чата.
    await bot.send_message(chat_id, text)


async def run_roulette_round(bot: Bot, chat_id: int) -> None:
    try:
        round_data = roulette_rounds[chat_id]

        await steady_countdown(
            bot,
            chat_id,
            round_data["message_id"],
            BET_TIME_SECONDS,
            lambda remaining: build_betting_text(round_data, remaining),
        )

        round_data["phase"] = "spinning"
        await safe_edit(
            bot, chat_id, round_data["message_id"],
            header("Дьявол", "😈") + "⛔ Ставки закрыты\n\n😈 Крутим колесо...",
        )

        # Результат определяет НАШ честный random — колесо только визуализирует его.
        result = random.choice(["red", "black"])

        # Рисование GIF — это работа с CPU (Pillow), поэтому уводим её в отдельный
        # поток через to_thread, чтобы не блокировать event loop бота на время отрисовки.
        gif_bytes = await asyncio.to_thread(generate_wheel_gif, result)
        await bot.send_animation(chat_id=chat_id, animation=BufferedInputFile(gif_bytes, filename="wheel.gif"))
        await asyncio.sleep(2.9)  # длительность анимации (~2.6 сек) + запас на загрузку файла

        await finish_roulette_round(bot, chat_id, result)
    finally:
        roulette_rounds.pop(chat_id, None)


# =====================================================================================
#  ОТМЕНА СТАВКИ: "отмена" / "убрать ставку"
# =====================================================================================

ROULETTE_CANCEL_WORDS = {"отмена", "убрать ставку", "отменить ставку"}


@router.message(F.text.func(lambda t: t.strip().lower() in ROULETTE_CANCEL_WORDS))
async def cancel_bet_handler(message: Message) -> None:
    chat_id = message.chat.id
    round_data = roulette_rounds.get(chat_id)
    uid = str(message.from_user.id)

    if round_data is None or round_data["phase"] != "betting" or uid not in round_data["bets"]:
        await message.reply("У вас нет активной ставки в текущем раунде «Дьявола».")
        return

    bet = round_data["bets"].pop(uid)
    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    user["balance"] += bet["amount"]
    user["total_wagered"] = max(0, user.get("total_wagered", 0) - bet["amount"])
    save_users()

    await message.reply(f"✅ Ставка отменена, возвращено {format_money(bet['amount'])}.")


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), F.text.regexp(ROULETTE_BET_PATTERN))
async def roulette_bet_handler(message: Message) -> None:
    """
    Проверка ставки вынесена в фильтр (F.text.regexp): если сообщение не похоже
    на ставку, aiogram сам передаёт его следующему подходящему хэндлеру
    (Мины, Апгрейд, админ-команды), а не глохнет здесь молча.
    """
    match = ROULETTE_BET_PATTERN.match(message.text.strip())
    amount = int(match.group(1))
    color = "red" if match.group(2).lower() == "к" else "black"

    if amount <= 0:
        await message.reply("Сумма ставки должна быть больше нуля.")
        return

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        return

    chat_id = message.chat.id
    round_data = roulette_rounds.get(chat_id)
    uid = str(message.from_user.id)
    uname = message.from_user.username or ""

    if round_data is None:
        if user["balance"] < amount:
            await message.reply("Недостаточно средств на балансе.")
            return

        user["balance"] -= amount
        add_wagered(user, amount)
        save_users()

        round_data = {
            "phase": "betting",
            "bets": {uid: {"amount": amount, "color": color, "username": uname}},
            "message_id": None,
        }
        roulette_rounds[chat_id] = round_data

        sent = await message.answer(build_betting_text(round_data, BET_TIME_SECONDS))
        round_data["message_id"] = sent.message_id
        asyncio.create_task(run_roulette_round(message.bot, chat_id))
        return

    if round_data["phase"] != "betting":
        await message.reply("⛔ Ставки на этот раунд уже закрыты, дождитесь следующего раунда.")
        return

    existing_bet = round_data["bets"].get(uid)
    if existing_bet and existing_bet["color"] != color:
        await message.reply("Вы уже сделали ставку на другой цвет в этом раунде.")
        return

    if user["balance"] < amount:
        await message.reply("Недостаточно средств на балансе.")
        return

    user["balance"] -= amount
    add_wagered(user, amount)
    save_users()

    if existing_bet:
        existing_bet["amount"] += amount
    else:
        round_data["bets"][uid] = {"amount": amount, "color": color, "username": uname}
