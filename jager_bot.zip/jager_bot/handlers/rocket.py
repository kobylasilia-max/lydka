# =====================================================================================
#  handlers/rocket.py — "РАКЕТА" (crash-игра): "ракета 500" -> "забрать"
# =====================================================================================
#
#  Правила: во время фазы ставок все пишут "ракета <сумма>". Когда приём ставок
#  закрывается, множитель начинает расти в реальном времени (1.00x и выше).
#  Каждый может в любой момент написать "забрать" — тогда он получает свою ставку,
#  умноженную на множитель В ЭТОТ МОМЕНТ. Кто не успел — теряет ставку целиком,
#  когда ракета "взрывается".
#
#  Честность: момент взрыва выбирается СЛУЧАЙНО и ЗАРАНЕЕ (до начала полёта, скрыто
#  от игроков) по той же формуле, что и в Апгрейде — crash = RTP / u, где u равномерно
#  распределено. Это даёт P(долетит до X) = RTP/X — то же самое соотношение
#  риска/награды, что и во всех остальных играх бота.
#
#  Технически это ЕДИНСТВЕННАЯ игра в боте, где нужно live-обновлять число в реальном
#  времени с точностью до долей секунды — используем тот же fire-and-forget подход,
#  что и в остальных таймерах (см. utils.steady_countdown), чтобы не лагало.
# =====================================================================================

import asyncio
import math
import random
import re
import time

from aiogram import Router, F, Bot
from aiogram.enums import ChatType
from aiogram.types import Message, BufferedInputFile

from config import (
    BET_TIME_SECONDS, GAME_RTP, ROCKET_GROWTH_PER_SEC, ROCKET_TICK_SECONDS,
    ROCKET_MAX_ROUND_SECONDS, ROCKET_MAX_MULTIPLIER, DIVIDER,
)
from storage import get_user, format_money, save_users, add_wagered
from utils import header, safe_edit, steady_countdown
from rocket_render import generate_explosion_gif
from referrals import check_and_notify_referral

router = Router(name="rocket")

rocket_rounds: dict[int, dict] = {}          # chat_id -> состояние раунда
rocket_locks: dict[int, asyncio.Lock] = {}   # chat_id -> блокировка на раунд

ROCKET_BET_PATTERN = re.compile(r"^\s*ракета\s+(\d+)\s*$", re.IGNORECASE)
CASHOUT_WORDS = {"забрать", "забрать ракету", "кэшаут", "cashout"}


def get_rocket_lock(chat_id: int) -> asyncio.Lock:
    if chat_id not in rocket_locks:
        rocket_locks[chat_id] = asyncio.Lock()
    return rocket_locks[chat_id]


def _roll_crash_point() -> float:
    """Честный момент взрыва: та же формула RTP/u, что и в Апгрейде (см. gamemath.py)."""
    u = random.uniform(0.001, 0.999)
    return min(ROCKET_MAX_MULTIPLIER, max(1.01, GAME_RTP / u))


def _current_multiplier(elapsed: float) -> float:
    return math.exp(ROCKET_GROWTH_PER_SEC * elapsed)


def _build_flight_text(round_data: dict, current_mult: float) -> str:
    lines = [
        header("Ракета", "🚀"),
        f"Множитель: <b>x{current_mult:.2f}</b>",
        "",
        "Напишите «забрать», чтобы зафиксировать выигрыш прямо сейчас!",
        DIVIDER,
    ]
    cashed = [b for b in round_data["bets"].values() if b["cashed_out"]]
    if cashed:
        lines.append("✅ Уже забрали:")
        for b in cashed:
            name = f"@{b['username']}" if b["username"] else "игрок"
            lines.append(f"{name} — x{b['cashout_multiplier']:.2f} (+{format_money(b['payout'])})")
    else:
        lines.append("Пока никто не забрал.")
    return "\n".join(lines)


def _build_betting_text(round_data: dict, remaining: int) -> str:
    total = sum(b["amount"] for b in round_data["bets"].values())
    players = len(round_data["bets"])
    return (
        header("Ракета", "🚀")
        + f"⏱ До старта: <b>{remaining}</b> сек.\n\n"
        + f"👥 Игроков: {players}\n"
        + f"💰 Общий банк: {format_money(total)}\n"
        + f"{DIVIDER}\n"
        + "Ставка сообщением: <code>ракета 1000</code>"
    )


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), F.text.regexp(ROCKET_BET_PATTERN))
async def rocket_bet_handler(message: Message) -> None:
    match = ROCKET_BET_PATTERN.match(message.text.strip())
    amount = int(match.group(1))
    if amount <= 0:
        await message.reply("Сумма ставки должна быть больше нуля.")
        return

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        return

    chat_id = message.chat.id
    lock = get_rocket_lock(chat_id)
    async with lock:
        round_data = rocket_rounds.get(chat_id)
        uid = str(message.from_user.id)
        uname = message.from_user.username or ""

        if round_data is None:
            if user["balance"] < amount:
                await message.reply("Недостаточно средств на балансе.")
                return
            user["balance"] -= amount
            add_wagered(user, amount)
            save_users()

            round_data = {
                "phase": "betting",
                "bets": {uid: {"amount": amount, "username": uname, "cashed_out": False,
                                "cashout_multiplier": None, "payout": 0}},
                "message_id": None,
                "crash_point": _roll_crash_point(),
            }
            rocket_rounds[chat_id] = round_data

            sent = await message.answer(_build_betting_text(round_data, BET_TIME_SECONDS))
            round_data["message_id"] = sent.message_id
            asyncio.create_task(run_rocket_round(message.bot, chat_id))
            return

        if round_data["phase"] != "betting":
            await message.reply("⛔ Приём ставок уже закрыт, дождитесь следующего раунда.")
            return
        if uid in round_data["bets"]:
            await message.reply("Вы уже сделали ставку в этом раунде.")
            return
        if user["balance"] < amount:
            await message.reply("Недостаточно средств на балансе.")
            return

        user["balance"] -= amount
        add_wagered(user, amount)
        save_users()
        round_data["bets"][uid] = {
            "amount": amount, "username": uname, "cashed_out": False,
            "cashout_multiplier": None, "payout": 0,
        }


@router.message(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}), F.text.func(lambda t: t.strip().lower() in CASHOUT_WORDS))
async def rocket_cashout(message: Message) -> None:
    chat_id = message.chat.id
    round_data = rocket_rounds.get(chat_id)
    uid = str(message.from_user.id)

    if round_data is None or round_data["phase"] != "flying":
        await message.reply("Сейчас нет летящей ракеты.")
        return
    bet = round_data["bets"].get(uid)
    if bet is None:
        await message.reply("У вас нет ставки в этом раунде.")
        return
    if bet["cashed_out"]:
        await message.reply("Вы уже забрали выигрыш в этом раунде.")
        return

    lock = get_rocket_lock(chat_id)
    async with lock:
        # Повторная проверка внутри лока — на случай гонки с моментом краша.
        if round_data["phase"] != "flying" or bet["cashed_out"]:
            await message.reply("Не успели — ракета уже взорвалась.")
            return

        # ВАЖНО: множитель считаем ЗАНОВО от реального прошедшего времени, а не берём
        # из закэшированного round_data['live_multiplier'] — та переменная обновляется
        # только раз за цикл отображения и могла чуть отстать. Здесь же — честный
        # расчёт на самый последний момент, поэтому забрать можно ровно до миллисекунды
        # перед фактическим взрывом, без "невидимой" потери времени на лаг дисплея.
        elapsed = time.monotonic() - round_data["flight_start"]
        current_mult = _current_multiplier(elapsed)
        if current_mult >= round_data["crash_point"]:
            await message.reply("Не успели — ракета уже взорвалась.")
            return
        current_mult = min(current_mult, round_data["crash_point"])

        payout = int(bet["amount"] * current_mult)
        bet["cashed_out"] = True
        bet["cashout_multiplier"] = current_mult
        bet["payout"] = payout

        user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
        user["balance"] += payout
        user["wins"] += 1
        save_users()
        await check_and_notify_referral(message.bot, user)

    await message.reply(f"✅ Забрано на x{current_mult:.2f} — <b>+{format_money(payout)}</b>")


async def run_rocket_round(bot: Bot, chat_id: int) -> None:
    try:
        round_data = rocket_rounds[chat_id]

        # Фаза ставок — общий "не зависающий" таймер (см. utils.steady_countdown).
        await steady_countdown(
            bot, chat_id, round_data["message_id"], BET_TIME_SECONDS,
            lambda remaining: _build_betting_text(round_data, remaining),
        )

        round_data["phase"] = "flying"
        flight_start = time.monotonic()
        round_data["flight_start"] = flight_start
        crash_point = round_data["crash_point"]

        # ВАЖНО: расчёт "не взорвались ли" полностью независим от отрисовки —
        # опрашивается каждые 0.05с само по себе. Правка сообщения — фоновая задача
        # с ограничением "не более одной одновременно" (тот же принцип, что и в
        # utils.steady_countdown): если предыдущая правка ещё летит по сети, цикл
        # не ждёт её и не блокируется, крах всё равно наступит вовремя по часам.
        pending_edit: asyncio.Task | None = None
        last_edit_at = 0.0
        while True:
            elapsed = time.monotonic() - flight_start
            current_mult = _current_multiplier(elapsed)

            if current_mult >= crash_point or elapsed >= ROCKET_MAX_ROUND_SECONDS:
                round_data["live_multiplier"] = crash_point
                break

            round_data["live_multiplier"] = current_mult
            now = time.monotonic()
            slot_free = pending_edit is None or pending_edit.done()
            if slot_free and now - last_edit_at >= ROCKET_TICK_SECONDS:
                pending_edit = asyncio.create_task(
                    safe_edit(bot, chat_id, round_data["message_id"], _build_flight_text(round_data, current_mult))
                )
                last_edit_at = now

            await asyncio.sleep(0.05)

        round_data["phase"] = "crashed"

        # Взрыв: гифка — CPU-задача, уводим в отдельный поток.
        gif_bytes = await asyncio.to_thread(generate_explosion_gif, f"x{crash_point:.2f}")
        await safe_edit(bot, chat_id, round_data["message_id"],
                         header("Ракета", "🚀") + f"💥 Взорвалась на <b>x{crash_point:.2f}</b>!")
        await bot.send_animation(chat_id=chat_id, animation=BufferedInputFile(gif_bytes, filename="rocket_crash.gif"))
        await asyncio.sleep(1.3)

        winners_lines, losers_lines = [], []
        for uid, bet in round_data["bets"].items():
            name = f"@{bet['username']}" if bet["username"] else f"id{uid}"
            if bet["cashed_out"]:
                winners_lines.append(f"✅ {name} — x{bet['cashout_multiplier']:.2f} (+{format_money(bet['payout'])})")
            else:
                profile = get_user(int(uid))
                profile["losses"] += 1
                losers_lines.append(f"💥 {name} — потерял {format_money(bet['amount'])}")
                await check_and_notify_referral(bot, profile)
        save_users()

        text = header("Ракета", "🚀") + f"Взрыв на <b>x{crash_point:.2f}</b>\n\n"
        if winners_lines:
            text += "🏆 <b>Успели забрать:</b>\n" + "\n".join(winners_lines) + "\n\n"
        if losers_lines:
            text += "💥 <b>Не успели:</b>\n" + "\n".join(losers_lines)
        if not winners_lines and not losers_lines:
            text += "Раунд без ставок."

        # Новым сообщением — появится сразу под гифкой взрыва.
        await bot.send_message(chat_id, text)
    finally:
        rocket_rounds.pop(chat_id, None)
        rocket_locks.pop(chat_id, None)
