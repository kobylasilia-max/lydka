# =====================================================================================
#  handlers/upgrade.py — АПГРЕЙД: "апгрейд 5000"
# =====================================================================================
#
#  Игрок делает ставку, выбирает целевой множитель (x1.5 ... x100) — чем выше,
#  тем ниже шанс выиграть, но выигрыш кратно больше. Шансы считаются формулой
#  из gamemath.py под общий RTP казино (см. config.GAME_RTP). Итог определяет
#  наш честный random() СРАЗУ (до анимации) — зелёно-красное колесо лишь
#  визуализирует уже готовый результат, пропорционально реальному шансу.
# =====================================================================================

import asyncio
import random
import re

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, BufferedInputFile

from config import UPGRADE_MULTIPLIERS, DIVIDER
from storage import get_user, format_money, save_users, add_wagered
from utils import header
from gamemath import upgrade_win_chance
from upgrade_wheel import generate_upgrade_wheel_gif
from referrals import check_and_notify_referral

router = Router(name="upgrade")

upgrade_games: dict[str, dict] = {}          # str(user_id) -> состояние сессии
upgrade_locks: dict[str, asyncio.Lock] = {}  # str(user_id) -> персональная блокировка

UPGRADE_TEXT_PATTERN = re.compile(r"^\s*апгрейд\s+(\d+)\s*$", re.IGNORECASE)


def get_upgrade_lock(uid: str) -> asyncio.Lock:
    if uid not in upgrade_locks:
        upgrade_locks[uid] = asyncio.Lock()
    return upgrade_locks[uid]


def upgrade_pick_keyboard(owner_id: int) -> InlineKeyboardMarkup:
    rows = []
    row = []
    for i, mult in enumerate(UPGRADE_MULTIPLIERS):
        chance = upgrade_win_chance(mult) * 100
        label = f"x{mult:g} ({chance:.1f}%)"
        row.append(InlineKeyboardButton(text=label, callback_data=f"upgrade_pick:{owner_id}:{i}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.regexp(UPGRADE_TEXT_PATTERN))
async def cmd_upgrade(message: Message) -> None:
    match = UPGRADE_TEXT_PATTERN.match(message.text.strip())
    bet = int(match.group(1))

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        await message.answer("🚫 Вы заблокированы и не можете играть.")
        return

    uid = str(message.from_user.id)
    lock = get_upgrade_lock(uid)
    async with lock:
        if uid in upgrade_games:
            await message.answer("⛔ У вас уже есть активная игра Апгрейд. Дождитесь её завершения.")
            return
        if bet <= 0:
            await message.answer("Сумма ставки должна быть больше нуля.")
            return
        if user["balance"] < bet:
            await message.answer("Недостаточно средств на балансе.")
            return

        user["balance"] -= bet
        add_wagered(user, bet)
        save_users()

        upgrade_games[uid] = {
            "bet": bet,
            "chat_id": message.chat.id,
            "message_id": None,
            "owner_id": message.from_user.id,
        }

        text = (
            header("Апгрейд", "🚀")
            + f"Ставка: <b>{format_money(bet)}</b>\n"
            + f"{DIVIDER}\n"
            + "Выберите множитель — чем выше, тем меньше шанс:"
        )
        sent = await message.answer(text, reply_markup=upgrade_pick_keyboard(message.from_user.id))
        upgrade_games[uid]["message_id"] = sent.message_id


@router.callback_query(F.data.startswith("upgrade_pick:"))
async def cb_upgrade_pick(callback: CallbackQuery) -> None:
    try:
        _, owner_id_str, idx_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        idx = int(idx_str)
        multiplier = UPGRADE_MULTIPLIERS[idx]
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваша игра.", show_alert=True)
        return

    uid = str(owner_id)
    lock = get_upgrade_lock(uid)

    async with lock:
        game = upgrade_games.get(uid)
        if game is None or game["message_id"] != callback.message.message_id:
            await callback.answer("Эта игра уже завершена.", show_alert=True)
            return

        chance = upgrade_win_chance(multiplier)
        win = random.random() < chance  # результат готов СРАЗУ, колесо только показывает его

        # Мгновенный ответ на нажатие — до дальнейших сетевых запросов.
        await callback.answer(f"Выбрано x{multiplier:g}, крутим колесо...")

        await callback.message.edit_text(
            header("Апгрейд", "🚀")
            + f"Ставка: <b>{format_money(game['bet'])}</b>\n"
            + f"Множитель: <b>x{multiplier:g}</b> (шанс {chance*100:.1f}%)\n\n"
            + "🎡 Крутим колесо..."
        )

        # Рисование GIF — CPU-задача (Pillow), уводим в отдельный поток,
        # чтобы не блокировать event loop бота на время отрисовки.
        gif_bytes = await asyncio.to_thread(generate_upgrade_wheel_gif, win, chance)
        await callback.bot.send_animation(
            chat_id=game["chat_id"],
            animation=BufferedInputFile(gif_bytes, filename="upgrade_wheel.gif"),
        )
        await asyncio.sleep(2.9)  # длительность анимации (~2.6 сек) + запас на загрузку файла

        profile = get_user(owner_id)
        if win:
            payout = int(game["bet"] * multiplier)
            profile["balance"] += payout
            profile["wins"] += 1
            result_text = (
                header("Апгрейд", "🎉")
                + f"Победа! Множитель x{multiplier:g}\n"
                + f"Выигрыш: <b>{format_money(payout)}</b>"
            )
        else:
            profile["losses"] += 1
            result_text = (
                header("Апгрейд", "💥")
                + f"Не повезло — зелёный сектор не выпал.\n"
                + f"Потеряно: <b>{format_money(game['bet'])}</b>"
            )
        save_users()
        await check_and_notify_referral(callback.bot, profile)

        # Новым сообщением — появится сразу под анимацией колеса, а не выше неё.
        await callback.bot.send_message(game["chat_id"], result_text)

        upgrade_games.pop(uid, None)
