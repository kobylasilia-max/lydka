# =====================================================================================
#  handlers/general.py — /jager, /start, Баланс, Топ, Дейли, Помощь, Перевести, Рефералы
# =====================================================================================

import re
import random
from datetime import datetime, timedelta

from aiogram import Router, F
from aiogram.filters import Command, CommandStart, CommandObject
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

import runtime
import storage
from config import (
    DAILY_MIN, DAILY_MAX, DAILY_COOLDOWN_HOURS, DIVIDER,
    REFERRAL_REWARD_REGULAR, REFERRAL_REWARD_PREMIUM, REFERRAL_CHAIN_REWARD, REFERRAL_MIN_GAMES,
)
from keyboards import main_menu_keyboard
from storage import get_user, find_user_by_username, format_money, display_name, display_name_no_ping, save_users
from utils import header, is_admin

router = Router(name="general")


def _welcome_text(user: dict) -> str:
    return (
        header("JAGER CASINO", "🎰")
        + f"Стартовый баланс: <b>{format_money(user['balance'])}</b>\n\n"
        + "<b>📋 Команды:</b>\n"
        + "Баланс — профиль и баланс\n"
        + "Места — рейтинг игроков\n"
        + "Дейли — награда за день\n"
        + "Рефералы — ваша ссылка и статистика\n"
        + "Подарок — обменять Telegram-подарок на монеты\n"
        + "Хелп — список команд\n"
        + "Перевести @username 1000 — перевод денег\n\n"
        + "<b>🎮 Игры:</b>\n"
        + "😈 Дьявол (в группе) — <code>1000 к</code> или <code>1000 ч</code>\n"
        + "💣 Мины 500 — выбор сложности и клетки\n"
        + "🧨 Сапёр 500 — как Мины, но с числами-подсказками\n"
        + "🚀 Апгрейд 500 — выбор множителя и колесо\n"
        + "🛸 Ракета (в группе) — <code>ракета 500</code>, потом «забрать»\n\n"
        + "<b>🏦 Банк-вклад:</b>\n"
        + "Банк — посмотреть вклад\n"
        + "Вложить 1000 / Снять 1000 — пополнить/забрать со вклада\n\n"
        + "Удачи! 🍀"
    )


# =====================================================================================
#  /jager И /start — ТОЧКИ ВХОДА (start нужен для реферальных диплинков)
# =====================================================================================

@router.message(Command("jager"))
async def cmd_jager(message: Message) -> None:
    user = get_user(
        message.from_user.id, message.from_user.username, message.from_user.full_name,
        message.from_user.is_premium,
    )
    await message.answer(_welcome_text(user), reply_markup=main_menu_keyboard())


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject) -> None:
    """
    Telegram диплинки (t.me/ИмяБота?start=ПАРАМЕТР) всегда приходят именно как /start
    с этим параметром — поэтому реферальную ссылку можно поймать только здесь.
    Награда рефереру начисляется НЕ сразу, а после того как приглашённый наберёт
    REFERRAL_MIN_GAMES игр (см. referrals.py) — это защита от накрутки пустыми аккаунтами.
    """
    uid = str(message.from_user.id)
    is_brand_new = uid not in storage.users_data

    user = get_user(
        message.from_user.id, message.from_user.username, message.from_user.full_name,
        message.from_user.is_premium,
    )

    if is_brand_new and command.args and command.args.isdigit():
        referrer_id = int(command.args)
        if referrer_id != message.from_user.id:
            user["referred_by"] = referrer_id
            save_users()

    await message.answer(_welcome_text(user), reply_markup=main_menu_keyboard())


# =====================================================================================
#  ПОМОЩЬ
# =====================================================================================

async def show_help(message: Message) -> None:
    text = (
        header("Команды", "📖")
        + "Баланс — профиль и баланс\n"
        + "Места — рейтинг игроков\n"
        + "Дейли — награда за день\n"
        + "Рефералы — ваша ссылка и статистика\n"
        + "Подарок — обменять Telegram-подарок на монеты\n"
        + "Перевести @username сумма — перевод денег\n\n"
        + "😈 Дьявол (в группе): <code>1000 к</code> или <code>1000 ч</code>\n"
        + "Отмена — убрать ставку в текущем раунде\n"
        + "💣 Мины 500 — выбор сложности, потом клетки\n"
        + "Отмена мины — если игра зависла, вернуть ставку\n"
        + "🧨 Сапёр 500 — как Мины, но видно число мин вокруг клетки\n"
        + "Отмена сапёр — если игра зависла, вернуть ставку\n"
        + "🚀 Апгрейд 500 — выбор множителя, колесо решает\n"
        + "🛸 Ракета (в группе): <code>ракета 500</code>, потом «забрать»\n"
        + "🏦 Банк / Вложить 1000 / Снять 1000 — вклад под проценты\n"
    )
    if is_admin(message.from_user.id):
        text += (
            f"\n{DIVIDER}\n<b>🛠 Админ:</b>\n"
            "выдать @username 1000\n"
            "снять @username 1000\n"
            "установить @username 1000\n"
            "забанить @username / разбанить @username\n"
        )
    await message.answer(text)


# =====================================================================================
#  БАЛАНС / ПРОФИЛЬ
# =====================================================================================

async def show_balance(message: Message) -> None:
    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    reg_date = datetime.fromisoformat(user["registered_at"]).strftime("%d.%m.%Y")
    total_games = user["wins"] + user["losses"]
    winrate = (user["wins"] / total_games * 100) if total_games else 0.0
    status = "🚫 Заблокирован" if user.get("banned") else "✅ Активен"

    text = (
        header("Ваш профиль", "👤")
        + f"Имя: {user['name'] or '—'}\n"
        + f"Username: {'@' + user['username'] if user['username'] else '—'}\n"
        + f"Статус: {status}\n\n"
        + f"💰 Баланс: <b>{format_money(user['balance'])}</b>\n"
        + f"🏆 Победы: {user['wins']}\n"
        + f"💀 Поражения: {user['losses']}\n"
        + f"📊 Winrate: {winrate:.1f}%\n\n"
        + f"📅 Регистрация: {reg_date}"
    )
    await message.answer(text)


# =====================================================================================
#  ТОП
# =====================================================================================

async def show_top(message: Message) -> None:
    if not storage.users_data:
        await message.answer("Пока никто не зарегистрирован.")
        return

    ranked = sorted(storage.users_data.values(), key=lambda p: p["balance"], reverse=True)[:10]
    medals = ["🥇", "🥈", "🥉"]
    lines = [header("Топ игроков", "🏆").rstrip()]
    for i, profile in enumerate(ranked):
        prefix = medals[i] if i < 3 else f"{i + 1}."
        lines.append(f"{prefix} {display_name_no_ping(profile)} — {format_money(profile['balance'])}")
    await message.answer("\n".join(lines))


# =====================================================================================
#  ДЕЙЛИ
# =====================================================================================

DAILY_PENDING: dict[str, dict] = {}  # str(user_id) -> {"answer", "chat_id", "message_id"}


def _generate_daily_question() -> tuple[str, int]:
    a, b = random.randint(2, 20), random.randint(2, 20)
    op = random.choice(["+", "-"])
    if op == "-" and a < b:
        a, b = b, a
    answer = a + b if op == "+" else a - b
    return f"{a} {op} {b}", answer


def _build_daily_options(correct: int) -> list[int]:
    options = {correct}
    while len(options) < 4:
        candidate = correct + random.choice([-4, -3, -2, -1, 1, 2, 3, 4])
        if candidate >= 0:
            options.add(candidate)
    options = list(options)
    random.shuffle(options)
    return options


async def give_daily(message: Message) -> None:
    """
    Дейли теперь начинается с простой проверки (пример на сложение/вычитание) —
    небольшая защита от бездумного авто-кликанья и небольшое развлечение.
    За неё награда стала заметно выше, чем раньше.
    """
    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)

    if user.get("banned"):
        await message.answer("🚫 Вы заблокированы и не можете получать награды.")
        return

    now = datetime.now()
    if user["last_daily"]:
        last = datetime.fromisoformat(user["last_daily"])
        next_available = last + timedelta(hours=DAILY_COOLDOWN_HOURS)
        if now < next_available:
            remaining = next_available - now
            hours, rem = divmod(int(remaining.total_seconds()), 3600)
            minutes = rem // 60
            await message.answer(f"⏳ Награда уже забрана сегодня.\nСледующая через {hours} ч. {minutes} мин.")
            return

    question, answer = _generate_daily_question()
    options = _build_daily_options(answer)
    owner_id = message.from_user.id

    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=str(o), callback_data=f"daily_answer:{owner_id}:{o}") for o in options
    ]])

    text = (
        header("Дейли — проверка", "🎁")
        + f"Решите пример, чтобы получить награду:\n\n"
        + f"<b>{question} = ?</b>"
    )
    sent = await message.answer(text, reply_markup=keyboard)
    DAILY_PENDING[str(owner_id)] = {"answer": answer, "chat_id": message.chat.id, "message_id": sent.message_id}


@router.callback_query(F.data.startswith("daily_answer:"))
async def cb_daily_answer(callback: CallbackQuery) -> None:
    try:
        _, owner_id_str, selected_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        selected = int(selected_str)
    except (ValueError, IndexError):
        await callback.answer()
        return

    if callback.from_user.id != owner_id:
        await callback.answer("Это не ваш вопрос.", show_alert=True)
        return

    uid = str(owner_id)
    pending = DAILY_PENDING.get(uid)
    if pending is None or pending["message_id"] != callback.message.message_id:
        await callback.answer("Этот вопрос уже неактуален.", show_alert=True)
        return

    DAILY_PENDING.pop(uid, None)

    if selected != pending["answer"]:
        await callback.answer("❌ Неверно!", show_alert=True)
        await callback.message.edit_text(
            header("Дейли", "🎁") + "❌ Неверный ответ. Попробуйте ещё раз командой «дейли»."
        )
        return

    user = get_user(owner_id, callback.from_user.username, callback.from_user.full_name)
    reward = random.randint(DAILY_MIN, DAILY_MAX)
    user["balance"] += reward
    user["last_daily"] = datetime.now().isoformat()
    save_users()

    await callback.answer("✅ Верно!")
    text = (
        header("Ежедневная награда", "🎁")
        + f"Получено: <b>+{format_money(reward)}</b>\n"
        + f"Баланс: <b>{format_money(user['balance'])}</b>"
    )
    await callback.message.edit_text(text)


# =====================================================================================
#  РЕФЕРАЛЫ
# =====================================================================================

async def show_referrals(message: Message) -> None:
    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    my_id = message.from_user.id

    total_invited = 0
    rewarded = 0
    pending = 0
    for profile in storage.users_data.values():
        if profile.get("referred_by") == my_id:
            total_invited += 1
            if profile.get("referral_rewarded"):
                rewarded += 1
            else:
                pending += 1

    bot_username = runtime.BOT_USERNAME
    link = f"https://t.me/{bot_username}?start={my_id}" if bot_username else "(ссылка появится чуть позже, попробуйте ещё раз)"

    text = (
        header("Реферальная программа", "🤝")
        + f"Ваша ссылка:\n<code>{link}</code>\n\n"
        + f"За приглашённого без Premium — <b>{format_money(REFERRAL_REWARD_REGULAR)}</b>\n"
        + f"За приглашённого с Premium — <b>{format_money(REFERRAL_REWARD_PREMIUM)}</b>\n"
        + f"Награда приходит, когда он сыграет {REFERRAL_MIN_GAMES}+ игр.\n\n"
        + f"Если ваш реферал потом сам кого-то пригласит — вам ещё "
        + f"<b>{format_money(REFERRAL_CHAIN_REWARD)}</b> (за любого).\n\n"
        + f"👥 Всего приглашено: {total_invited}\n"
        + f"✅ Награда начислена: {rewarded}\n"
        + f"⏳ Ещё набирают игры: {pending}\n"
        + f"💰 Всего заработано: {format_money(user.get('referral_earned', 0))}"
    )
    await message.answer(text)


SIMPLE_TEXT_COMMANDS = {
    "баланс": show_balance,
    "профиль": show_balance,
    "балик": show_balance,
    "топ": show_top,
    "места": show_top,
    "дейли": give_daily,
    "ежедневная": give_daily,
    "ежедневная награда": give_daily,
    "помощь": show_help,
    "команды": show_help,
    "хелп": show_help,
    "рефералы": show_referrals,
    "реферал": show_referrals,
    "реферальная программа": show_referrals,
}


@router.message(F.text.func(lambda t: t.strip().lower() in SIMPLE_TEXT_COMMANDS))
async def simple_text_command_handler(message: Message) -> None:
    handler_fn = SIMPLE_TEXT_COMMANDS[message.text.strip().lower()]
    await handler_fn(message)


# =====================================================================================
#  ПЕРЕВОД ДЕНЕГ: "перевести @username 1000"
# =====================================================================================

PAY_PATTERN = re.compile(r"^\s*перевести\s+(\S+)\s+(\d+)\s*$", re.IGNORECASE)


@router.message(F.text.regexp(PAY_PATTERN))
async def cmd_pay(message: Message) -> None:
    match = PAY_PATTERN.match(message.text.strip())
    target_raw, amount_str = match.group(1), match.group(2)
    amount = int(amount_str)

    sender = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if sender.get("banned"):
        await message.answer("🚫 Вы заблокированы и не можете переводить деньги.")
        return
    if amount <= 0:
        await message.answer("Сумма должна быть больше нуля.")
        return

    receiver = find_user_by_username(target_raw)
    if receiver is None:
        await message.answer("Пользователь с таким username не найден в базе бота.")
        return
    if receiver["id"] == sender["id"]:
        await message.answer("Нельзя перевести деньги самому себе.")
        return
    if sender["balance"] < amount:
        await message.answer("Недостаточно средств для перевода.")
        return

    sender["balance"] -= amount
    receiver["balance"] += amount
    save_users()

    text = (
        header("Перевод выполнен", "💸")
        + f"Кому: {display_name(receiver)}\n"
        + f"Сумма: {format_money(amount)}\n"
        + f"Ваш новый баланс: {format_money(sender['balance'])}"
    )
    await message.answer(text)
