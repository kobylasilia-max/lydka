# =====================================================================================
#  handlers/vault.py — БАНК-ВКЛАД С ПРОЦЕНТАМИ ("банк", "вложить N", "снять N")
# =====================================================================================
#
#  Проценты начисляются НЕПРЕРЫВНО и пропорционально времени — не только по целым
#  часам. Механизм: у профиля хранится vault_balance (сколько сейчас на вкладе) и
#  vault_updated_at (когда в последний раз "закрывали" период). При любом действии
#  (посмотреть баланс, довнести, снять) мы сначала "рассчитываемся" — считаем,
#  сколько процентов накапало с момента vault_updated_at, добавляем их к
#  vault_balance, и обнуляем таймер. Именно поэтому довнесение "в последнюю минуту"
#  считается корректно: до довнесения settle фиксирует проценты по СТАРОЙ сумме,
#  а новая часть начинает копить проценты с нуля, с этого самого момента.
# =====================================================================================

import re
from datetime import datetime

from aiogram import Router, F
from aiogram.types import Message

from config import VAULT_HOURLY_RATE, DIVIDER
from storage import get_user, format_money, save_users
from utils import header

router = Router(name="vault")

VAULT_VIEW_WORDS = {"банк", "вклад"}
DEPOSIT_PATTERN = re.compile(r"^\s*вложить\s+(\d+|всё|все)\s*$", re.IGNORECASE)
WITHDRAW_PATTERN = re.compile(r"^\s*снять\s+(\d+|всё|все)\s*$", re.IGNORECASE)


def _settle_vault(profile: dict) -> None:
    """Фиксирует накопленные проценты в vault_balance и сдвигает таймер на 'сейчас'."""
    now = datetime.now()
    last_str = profile.get("vault_updated_at")
    balance = profile.get("vault_balance", 0.0)

    if last_str and balance > 0:
        last = datetime.fromisoformat(last_str)
        elapsed_hours = max(0.0, (now - last).total_seconds() / 3600)
        if elapsed_hours > 0:
            interest = balance * VAULT_HOURLY_RATE * elapsed_hours
            profile["vault_balance"] = balance + interest

    profile["vault_updated_at"] = now.isoformat()


@router.message(F.text.func(lambda t: t.strip().lower() in VAULT_VIEW_WORDS))
async def show_vault(message: Message) -> None:
    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    _settle_vault(user)
    save_users()

    text = (
        header("Банк-вклад", "🏦")
        + f"На вкладе: <b>{format_money(int(user['vault_balance']))}</b>\n"
        + f"Ставка: {VAULT_HOURLY_RATE*100:.0f}% в час (начисляется непрерывно)\n"
        + f"{DIVIDER}\n"
        + "Вложить: <code>вложить 1000</code>\n"
        + "Снять: <code>снять 1000</code> (или «снять всё»)"
    )
    await message.answer(text)


@router.message(F.text.regexp(DEPOSIT_PATTERN))
async def deposit(message: Message) -> None:
    match = DEPOSIT_PATTERN.match(message.text.strip())
    raw = match.group(1).lower()

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    if user.get("banned"):
        await message.answer("🚫 Вы заблокированы.")
        return

    amount = user["balance"] if raw in ("всё", "все") else int(raw)
    if amount <= 0:
        await message.answer("Сумма должна быть больше нуля.")
        return
    if user["balance"] < amount:
        await message.answer("Недостаточно средств на балансе.")
        return

    # Сначала settle — проценты по уже лежавшей сумме считаются ДО того, как
    # к вкладу добавится новая часть (иначе новые деньги задним числом получили
    # бы проценты, которых на самом деле не заработали).
    _settle_vault(user)

    user["balance"] -= amount
    user["vault_balance"] = user.get("vault_balance", 0.0) + amount
    save_users()

    text = (
        header("Вклад пополнен", "🏦")
        + f"Внесено: <b>{format_money(amount)}</b>\n"
        + f"На вкладе: {format_money(int(user['vault_balance']))}\n"
        + f"Баланс: {format_money(user['balance'])}"
    )
    await message.answer(text)


@router.message(F.text.regexp(WITHDRAW_PATTERN))
async def withdraw(message: Message) -> None:
    match = WITHDRAW_PATTERN.match(message.text.strip())
    raw = match.group(1).lower()

    user = get_user(message.from_user.id, message.from_user.username, message.from_user.full_name)

    # Settle ПЕРВЫМ — чтобы забрать все проценты, накопленные вплоть до этой секунды.
    _settle_vault(user)

    amount = int(user["vault_balance"]) if raw in ("всё", "все") else int(raw)
    if amount <= 0:
        await message.answer("Сумма должна быть больше нуля.")
        return
    if user["vault_balance"] < amount:
        await message.answer(f"На вкладе только {format_money(int(user['vault_balance']))}.")
        return

    user["vault_balance"] -= amount
    user["balance"] += amount
    save_users()

    text = (
        header("Средства сняты", "🏦")
        + f"Снято: <b>{format_money(amount)}</b>\n"
        + f"На вкладе осталось: {format_money(int(user['vault_balance']))}\n"
        + f"Баланс: {format_money(user['balance'])}"
    )
    await message.answer(text)
