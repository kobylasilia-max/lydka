# =====================================================================================
#  handlers/gifts.py — НАСТОЯЩИЕ TELEGRAM-ПОДАРКИ -> МОНЕТЫ
# =====================================================================================
#
#  ВАЖНО: бот не может увидеть подарок, отправленный на ЛИЧНЫЙ аккаунт админа —
#  Bot API просто не даёт ботам доступ к чужой личной переписке, это в принципе
#  невозможно технически. Зато бот МОЖЕТ получать подарки САМ (как получатель) —
#  и в этом случае автоматически знает точную цену подарка в Stars. Поэтому монеты
#  начисляются за подарок, отправленный НЕПОСРЕДСТВЕННО БОТУ (через его профиль ->
#  значок подарка в Telegram), а не какому-то отдельному аккаунту.
#
#  Требует aiogram >= 3.30 (там появилась поддержка Gift/GiftInfo).
# =====================================================================================

from aiogram import Router, F
from aiogram.types import Message

from config import GIFT_COINS_PER_STAR, ADMIN_IDS
from storage import get_user, format_money, save_users, display_name
from utils import header

router = Router(name="gifts")

GIFT_INFO_WORDS = {"звезды", "звёзды", "донат", "stars", "старс", "подарок", "подарки"}


@router.message(F.text.func(lambda t: t.strip().lower() in GIFT_INFO_WORDS))
async def show_gift_instructions(message: Message) -> None:
    text = (
        header("Подарки -> монеты", "🎁")
        + "Отправьте боту настоящий подарок Telegram — монеты начислятся "
        + "автоматически, сразу после отправки.\n\n"
        + "Как отправить: откройте профиль бота -> значок подарка 🎁 -> выберите "
        + "любой подарок -> отправьте.\n\n"
        + f"Курс: <b>1⭐ = {format_money(GIFT_COINS_PER_STAR)}</b> монет "
        + "(зависит от цены самого подарка)."
    )
    await message.answer(text)


@router.message(F.gift)
async def handle_incoming_gift(message: Message) -> None:
    """Срабатывает, когда боту НАПРЯМУЮ отправили настоящий подарок Telegram."""
    gift_info = message.gift
    stars = gift_info.gift.star_count
    coins = int(stars * GIFT_COINS_PER_STAR)

    user = get_user(
        message.from_user.id, message.from_user.username, message.from_user.full_name,
        message.from_user.is_premium,
    )
    user["balance"] += coins
    save_users()

    await message.answer(
        header("Спасибо за подарок!", "🎁")
        + f"Подарок: {stars}⭐\n"
        + f"Начислено: <b>+{format_money(coins)}</b> монет"
    )

    notify = (
        f"🎁 <b>Получен подарок!</b>\n"
        f"От: {display_name(user)} (id{user['id']})\n"
        f"Подарок: {stars}⭐ -> начислено {format_money(coins)} монет"
    )
    for admin_id in ADMIN_IDS:
        try:
            await message.bot.send_message(admin_id, notify)
        except Exception:  # noqa: BLE001
            pass
