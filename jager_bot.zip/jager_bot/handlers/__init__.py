# =====================================================================================
#  handlers/__init__.py — собирает все роутеры категорий в один список
# =====================================================================================
#
#  Порядок важен только там, где фильтры могли бы пересекаться. Сейчас у каждого
#  хэндлера точный фильтр (своё регулярное выражение/слово), поэтому чужие категории
#  друг другу не мешают — это и есть отличие от старой версии, где рулетка ловила
#  вообще любой текст и глушила Мины.
# =====================================================================================

from . import general
from . import admin
from . import roulette
from . import mines
from . import sapper
from . import upgrade
from . import gifts
from . import vault
from . import rocket

all_routers = [
    general.router,
    admin.router,
    roulette.router,
    mines.router,
    sapper.router,
    upgrade.router,
    gifts.router,
    vault.router,
    rocket.router,
]
