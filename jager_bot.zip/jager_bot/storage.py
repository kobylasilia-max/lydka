# =====================================================================================
#  storage.py — ХРАНЕНИЕ ДАННЫХ (users.json), НЕБЛОКИРУЮЩЕЕ СОХРАНЕНИЕ
# =====================================================================================
#
#  Вся работа с балансами и профилями пользователей идёт через этот модуль.
#  Ключевой момент: save_users() НЕ пишет на диск синхронно — если бы она это делала,
#  event loop бота замирал бы на время записи файла, и все остальные пользователи
#  в этот момент не получали бы ответа (именно так раньше выглядели "лаги на 20 секунд").
#
# =====================================================================================

import asyncio
import json
import logging
import os
from datetime import datetime

from config import DATA_FILE, STARTING_BALANCE

logger = logging.getLogger(__name__)

users_data: dict[str, dict] = {}


def load_users() -> None:
    """Загружает данные пользователей из users.json при старте бота."""
    global users_data
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                users_data = json.load(f)
            logger.info("Загружено пользователей: %s", len(users_data))
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Не удалось прочитать %s: %s. Стартуем с пустой базой.", DATA_FILE, exc)
            users_data = {}
    else:
        users_data = {}


def _write_users_file() -> None:
    """Синхронная запись на диск. Вызывается ТОЛЬКО через asyncio.to_thread."""
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(users_data, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        logger.error("Не удалось сохранить %s: %s", DATA_FILE, exc)


_save_dirty = False
_save_task: asyncio.Task | None = None
_SAVE_DEBOUNCE_SECONDS = 0.4


async def _debounced_save_worker() -> None:
    global _save_dirty
    await asyncio.sleep(_SAVE_DEBOUNCE_SECONDS)
    if _save_dirty:
        _save_dirty = False
        await asyncio.to_thread(_write_users_file)


def save_users() -> None:
    """
    Планирует сохранение users.json, НЕ блокируя event loop.
    Запись уходит в отдельный поток и объединяется (дебаунс) с соседними вызовами.
    """
    global _save_dirty, _save_task
    _save_dirty = True
    if _save_task is None or _save_task.done():
        _save_task = asyncio.create_task(_debounced_save_worker())


async def flush_users_now() -> None:
    """Немедленно и принудительно сохраняет users.json (используется при остановке бота)."""
    global _save_dirty
    _save_dirty = False
    await asyncio.to_thread(_write_users_file)


def get_user(
    user_id: int,
    username: str | None = None,
    full_name: str | None = None,
    is_premium: bool | None = None,
) -> dict:
    """Возвращает профиль пользователя, создавая его при первом обращении."""
    uid = str(user_id)
    if uid not in users_data:
        users_data[uid] = {
            "id": user_id,
            "username": username or "",
            "name": full_name or "",
            "is_premium": bool(is_premium),
            "balance": STARTING_BALANCE,
            "wins": 0,
            "losses": 0,
            "registered_at": datetime.now().isoformat(),
            "last_daily": None,
            "banned": False,
            "referred_by": None,
            "referral_rewarded": False,
            "referral_earned": 0,
            "total_wagered": 0,
            "vault_balance": 0.0,
            "vault_updated_at": None,
        }
        save_users()
    else:
        profile = users_data[uid]
        changed = False
        if username is not None and profile["username"] != username:
            profile["username"] = username
            changed = True
        if full_name is not None and profile["name"] != full_name:
            profile["name"] = full_name
            changed = True
        if is_premium is not None and profile.get("is_premium") != is_premium:
            profile["is_premium"] = is_premium
            changed = True
        # Миграция старых профилей (созданных до появления новых полей) —
        # чтобы .get(...) с дефолтами не понадобился по всему остальному коду.
        defaults = (
            ("is_premium", False),
            ("referred_by", None), ("referral_rewarded", False), ("referral_earned", 0),
            ("total_wagered", 0),
            ("vault_balance", 0.0), ("vault_updated_at", None),
        )
        for key, default in defaults:
            if key not in profile:
                profile[key] = default
                changed = True
        if changed:
            save_users()
    return users_data[uid]


def add_wagered(profile: dict, amount: int) -> None:
    """Учитывает сумму ставки в общем обороте пользователя (используется рефералкой)."""
    profile["total_wagered"] = profile.get("total_wagered", 0) + amount


def find_user_by_username(username: str) -> dict | None:
    """Ищет пользователя по username (без учёта регистра и символа @)."""
    clean = username.lstrip("@").lower()
    for profile in users_data.values():
        if profile.get("username", "").lower() == clean:
            return profile
    return None


def resolve_target(raw: str, requester_id: int, requester_username: str | None, requester_full_name: str | None) -> dict | None:
    """
    Определяет пользователя-получателя по строке из команды:
    'себе' / 'мне' -> сам отправитель; '@username' или 'username' -> поиск по нику;
    число -> поиск/создание по Telegram ID.
    """
    low = raw.lower()
    if low in ("себя", "себе", "мне", "я"):
        return get_user(requester_id, requester_username, requester_full_name)
    if raw.isdigit():
        return get_user(int(raw))
    return find_user_by_username(raw)


def format_money(amount: int) -> str:
    """Форматирует число с разделением разрядов пробелом: 125000 -> '125 000'."""
    return f"{amount:,}".replace(",", " ")


def display_name(profile: dict) -> str:
    if profile.get("username"):
        return f"@{profile['username']}"
    return profile.get("name") or f"id{profile.get('id')}"


def display_name_no_ping(profile: dict) -> str:
    """
    То же самое, но БЕЗ символа '@' перед username — Telegram распознаёт мышление
    '@username' как упоминание и присылает человеку уведомление (пингует его).
    Используется там, где имя нужно просто показать (например, в топе игроков),
    а не специально уведомить человека.
    """
    if profile.get("name"):
        return profile["name"]
    if profile.get("username"):
        return profile["username"]
    return f"Игрок {profile.get('id')}"
