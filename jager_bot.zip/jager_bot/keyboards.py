# =====================================================================================
#  keyboards.py — ВСЕ КЛАВИАТУРЫ БОТА
# =====================================================================================

from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
)

from config import MINES_GRID_SIZE, MINES_TIERS, SAPPER_GRID_SIZE


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Баланс"), KeyboardButton(text="Места")],
            [KeyboardButton(text="Дейли"), KeyboardButton(text="Мины 500")],
            [KeyboardButton(text="Апгрейд 500"), KeyboardButton(text="Банк")],
            [KeyboardButton(text="Рефералы"), KeyboardButton(text="Подарок")],
            [KeyboardButton(text="Хелп")],
        ],
        resize_keyboard=True,
    )


def mines_tier_keyboard(owner_id: int, bet: int) -> InlineKeyboardMarkup:
    """Выбор сложности после 'мины <ставка>' — три категории с разным риском/наградой."""
    rows = [
        [InlineKeyboardButton(text=f"{label} ({count} мин)", callback_data=f"mines_tier:{owner_id}:{count}:{bet}")]
        for _key, count, label in MINES_TIERS
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def mines_keyboard(game: dict, owner_id: int, reveal_all: bool = False) -> InlineKeyboardMarkup:
    """Строит inline-сетку игры Мины 5x5 + кнопку вывода выигрыша."""
    rows: list[list[InlineKeyboardButton]] = []
    for r in range(MINES_GRID_SIZE):
        row = []
        for c in range(MINES_GRID_SIZE):
            idx = r * MINES_GRID_SIZE + c
            is_mine = idx in game["mines"]
            is_revealed = idx in game["revealed"]

            if is_mine and (reveal_all or is_revealed):
                label = "💣"
            elif is_revealed:
                label = "💎"
            else:
                label = "▪️"

            if is_revealed or reveal_all:
                callback_data = "mines_noop"
            else:
                callback_data = f"mines_cell:{owner_id}:{idx}"

            row.append(InlineKeyboardButton(text=label, callback_data=callback_data))
        rows.append(row)

    if not reveal_all:
        rows.append([InlineKeyboardButton(text="💰 Забрать выигрыш", callback_data=f"mines_cashout:{owner_id}")])

    return InlineKeyboardMarkup(inline_keyboard=rows)


_NUMBER_LABELS = {0: "▫️", 1: "1️⃣", 2: "2️⃣", 3: "3️⃣", 4: "4️⃣", 5: "5️⃣", 6: "6️⃣", 7: "7️⃣", 8: "8️⃣"}


def sapper_keyboard(game: dict, owner_id: int, reveal_all: bool = False) -> InlineKeyboardMarkup:
    """
    Сетка Сапёра: на открытых безопасных клетках видно число — сколько мин среди
    8 соседних клеток (классическая механика минного поля), а не просто 💎.
    """
    rows: list[list[InlineKeyboardButton]] = []
    for r in range(SAPPER_GRID_SIZE):
        row = []
        for c in range(SAPPER_GRID_SIZE):
            idx = r * SAPPER_GRID_SIZE + c
            is_mine = idx in game["mines"]
            is_revealed = idx in game["revealed"]

            if is_mine and (reveal_all or is_revealed):
                label = "💣"
            elif is_revealed:
                label = _NUMBER_LABELS.get(game["hints"].get(idx, 0), "▫️")
            else:
                label = "◽️"

            if is_revealed or reveal_all:
                callback_data = "sapper_noop"
            else:
                callback_data = f"sapper_cell:{owner_id}:{idx}"

            row.append(InlineKeyboardButton(text=label, callback_data=callback_data))
        rows.append(row)

    if not reveal_all:
        rows.append([InlineKeyboardButton(text="💰 Забрать выигрыш", callback_data=f"sapper_cashout:{owner_id}")])

    return InlineKeyboardMarkup(inline_keyboard=rows)
